#ifndef SC_W_CL_H
#define SC_W_CL_H
#include <QString>
class SC_W_CL
{
public:
    QString num;
    QString school_name;
    QString class_name;
};
#endif // SC_W_CL_H
