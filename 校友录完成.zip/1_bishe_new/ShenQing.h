#ifndef SHENQING_H
#define SHENQING_H
#include <QString>
class ShenQing
{
public:
    ShenQing(QString root_id = "",QString stu_no = "",QString flag = ""):ROOT_ID(root_id),STU_NO(stu_no),FLAG(flag){}
    QString ROOT_ID;
    QString STU_NO;
    QString FLAG;
};
#endif // SHENQING_H
