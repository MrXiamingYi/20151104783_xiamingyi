#include "rootwindow.h"
#include "ui_rootwindow.h"

rootWindow::rootWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::rootWindow)
{
    ui->setupUi(this);
    audio =new Phonon::MediaObject();//媒体对象
    audio->setTickInterval(1);
    audioOutput = new Phonon::AudioOutput(Phonon::VideoCategory);//音频输出
    Phonon::createPath( audio, audioOutput);//连接媒体对象与音频输出

    musicInformationMediaObject = new Phonon::MediaObject(this);  //音乐信息对象

    volumeSlider = new Phonon::VolumeSlider( audioOutput,this);  //音量滑动条
    volumeSlider->move(285,60);
    volumeSlider->resize(50,20);
    volumeSlider->setStyleSheet("background-color:rgb(255,255,255,100)");
    volumeSlider->setFixedWidth(100);//固定音量条大小

    seekSlider = new Phonon::SeekSlider( audio,this); //进度滑动条 将进度条与媒体对象连接
    seekSlider->move(240,20);
    seekSlider->resize(170,20);
    seekSlider->setStyleSheet("background-color:rgb(255,255,255,100)");

    QStandardItemModel *root_model = new QStandardItemModel();
    root_model->setHorizontalHeaderItem(0, new QStandardItem(QObject::tr("学号")));
    root_model->setHorizontalHeaderItem(1, new QStandardItem(QObject::tr("姓名")));
    root_model->setHorizontalHeaderItem(2, new QStandardItem(QObject::tr("处理类型")));
    //利用setModel()方法将数据模型与QTableView绑定
    ui->tableView_5->setModel(root_model);

    ui->tableView_5->setColumnWidth(0, 200);
    ui->tableView_5->setColumnWidth(1, 200);
    ui->tableView_5->setColumnWidth(2, 118);


}

rootWindow::~rootWindow()
{
    delete ui;
}

void rootWindow::recRootno(QString rootno)
{
    QString str = QString("已经传入账户号： %1").arg(rootno);
    qDebug()<<str;
    s_Rootno = rootno;
}

//播放/暂停
void rootWindow::on_toolButton_playpause_clicked(){
    if(sourceList.isEmpty())
        {
            return ;
        }
        audio->setQueue(sourceList);//列表循环

    if(audio->state() == Phonon::PlayingState)
        audio->pause();
    else
    {
        audio->play();
    }

}

//停止播放
void rootWindow::on_toolButton_stop_clicked(){
    audio->stop();
}

//打开文件
void rootWindow::on_toolButton_open_clicked(){

    QStringList files = QFileDialog::getOpenFileNames(this, tr("Selec Files to play"),QDesktopServices::storageLocation(QDesktopServices::MusicLocation));

    qDebug()<<"第"<<files<<"条";
    // 使用 QFileDialog 的 getOpenFileNames 方法获取若干个音乐文件，
    QString file;

    foreach(file, files)// 使用 Qt 中的 foreach 遍历每个选中的文件，将其添加到播放列表中。
    {
        QString muzicname;
        muzicname = file.section('/', -1);
        ui->listWidget->addItem(muzicname);
        sourceList.append(file);
    }
}

//上一首歌
void rootWindow::on_toolButton_previous_clicked()
{
    if(sourceList.count() != 0){
        /*查找当前媒体播放的位置，返回给index*/
        int index = sourceList.indexOf(audio->currentSource());
        qDebug()<<"共"<<sourceList.count()<<"条";
        qDebug()<<"第"<<index<<"条";
        if(index - 1 >= 0){
            audio->setCurrentSource(sourceList.at(index - 1));
            audio->play();
        }
        else {
            QMessageBox::information(this, "提示", "已经第一首了！", QMessageBox::Ok);
        }
    }
    else{
        QMessageBox::information(this, "提示", "播放列表为空", QMessageBox::Ok);
    }
}

//下一首
void rootWindow::on_toolButton_next_clicked()
{
    if(sourceList.count() != 0){
        int index = sourceList.indexOf(audio->currentSource());
        qDebug()<<"共"<<sourceList.count()<<"条";
        qDebug()<<"第"<<index<<"条";
        if(index +1 <= sourceList.count()-1){
            audio->setCurrentSource(sourceList.at(index + 1));
            audio->play();
        }
        else {
            QMessageBox::information(this, "提示", "已经最后一首了！", QMessageBox::Ok);
        }
    }
    else{
        QMessageBox::information(this, "提示", "播放列表为空", QMessageBox::Ok);
    }
}

//删除文件
void rootWindow::on_toolButton_lrcD_clicked()
{
    QStringList files = QFileDialog::getOpenFileNames(this, tr("delete muzic"),QDesktopServices::storageLocation(QDesktopServices::MusicLocation));
    QString file;
    foreach(file, files)// 使用 Qt 中的 foreach 遍历每个选中的文件，将其添加到播放列表中。
    {
        //删除文件
        QFile::remove(file); //提示
    }

    QMessageBox::warning(this,"删除文件","删除成功！");

}

void rootWindow::rowClicked()
{
    int row= ui->tableView_5->currentIndex().row();
    s_rcvClickednum = row;
    qDebug()<<"单击了第几行："<<s_rcvClickednum;
}

void rootWindow::on_pushButton_24_clicked()
{
    int count = selectShenqingOfRoot(QStoCH(s_Rootno));

    QStandardItemModel *fund_sq_of_stu = new QStandardItemModel();
    ui->tableView_5->setModel(fund_sq_of_stu);

    fund_sq_of_stu->clear();

    ui->tableView_5->setEditTriggers(QAbstractItemView::SelectedClicked); //单击
    ui->tableView_5->setSelectionBehavior(QAbstractItemView::SelectRows); //成条选
    ui->tableView_5->setEditTriggers(QAbstractItemView::NoEditTriggers);//禁止编辑
    fund_sq_of_stu->setHorizontalHeaderItem(0, new QStandardItem(QObject::tr("学号")));
    fund_sq_of_stu->setHorizontalHeaderItem(1, new QStandardItem(QObject::tr("姓名")));
    fund_sq_of_stu->setHorizontalHeaderItem(2, new QStandardItem(QObject::tr("处理状态")));

    ui->tableView_5->setColumnWidth(0, 200);
    ui->tableView_5->setColumnWidth(1, 200);
    ui->tableView_5->setColumnWidth(2, 100);

    QString listSC[count];
    ShenQing find[count];
    QStringList lst_of_sc;
    QFile file("./rootOfShenqingByStudent");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
        QTextStream stream(&file);
        for(int i = 0;i < count;i++)
        {
            listSC[i] = stream.readLine();
            lst_of_sc=listSC[i].split(QRegExp(" "));
            find[i].ROOT_ID = lst_of_sc[0];
            find[i].STU_NO  = lst_of_sc[1];
            find[i].FLAG    = lst_of_sc[2];
        }
    }
    file.close();
    for(int i = 0 ; i < count; i++){

        QStandardItem *item = new QStandardItem();
        Student student;
        getStudentOfStuNo(find[i].STU_NO,student);
        item->setCheckable(true);
        item->setText(QString::number(i));
        item->setCheckState(Qt::Unchecked);
        fund_sq_of_stu->setItem(i, 0, new QStandardItem(student.STU_NO));
        fund_sq_of_stu->setItem(i, 1, new QStandardItem(student.NAME));
        if(find[i].FLAG == "2"){
            fund_sq_of_stu->setItem(i, 2, new QStandardItem("等待解决"));
        }
        if(find[i].FLAG == "0"){
            fund_sq_of_stu->setItem(i, 2, new QStandardItem("已经拒绝"));
        }
        if(find[i].FLAG == "1"){
            fund_sq_of_stu->setItem(i, 2, new QStandardItem("已经加入"));
        }
    }
    s_rcvClickedCount = count;
    connect(ui->tableView_5, SIGNAL(clicked(const QModelIndex &)), this, SLOT(rowClicked()));
}

void rootWindow::on_pushButton_25_clicked()//yes
{
    ShenQing find[s_rcvClickedCount];
    QStringList lst_of_sc;
    QString listSC[s_rcvClickedCount];
    QString SchoolWithClassNo;
    QFile file("./rootOfShenqingByStudent");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
        QTextStream stream(&file);
        for(int i = 0;i < s_rcvClickedCount;i++)
        {
            listSC[i] = stream.readLine();
            lst_of_sc=listSC[i].split(QRegExp(" "));
            find[i].ROOT_ID = lst_of_sc[0];
            find[i].STU_NO  = lst_of_sc[1];
            find[i].FLAG    = lst_of_sc[2];
        }
    }
    file.close();
    if(find[s_rcvClickednum].FLAG == "2"){
        getRootWhihClass(find[s_rcvClickednum].ROOT_ID,SchoolWithClassNo);
        qDebug()<<"SchoolWithClassNo is "<<SchoolWithClassNo;
        insertUserWithClass(find[s_rcvClickednum].STU_NO,SchoolWithClassNo);
        updatShenQing(find[s_rcvClickednum].ROOT_ID,find[s_rcvClickednum].STU_NO,"1");
        QMessageBox::information(this, "提示", "处理完毕", QMessageBox::Ok);
    }
    else {
        QMessageBox::information(this, "提示", "重复操作", QMessageBox::Ok);
    }
}

void rootWindow::on_pushButton_27_clicked()//no
{
    ShenQing find[s_rcvClickedCount];
    QStringList lst_of_sc;
    QString listSC[s_rcvClickedCount];
    QString SchoolWithClassNo;
    QFile file("./rootOfShenqingByStudent");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
        QTextStream stream(&file);
        for(int i = 0;i < s_rcvClickedCount;i++)
        {
            listSC[i] = stream.readLine();
            lst_of_sc=listSC[i].split(QRegExp(" "));
            find[i].ROOT_ID = lst_of_sc[0];
            find[i].STU_NO  = lst_of_sc[1];
            find[i].FLAG    = lst_of_sc[2];
        }
    }
    file.close();
    if(find[s_rcvClickednum].FLAG == "2"){
        getRootWhihClass(find[s_rcvClickednum].ROOT_ID,SchoolWithClassNo);
        insertUserWithClass(find[s_rcvClickednum].STU_NO,SchoolWithClassNo);
        updatShenQing(find[s_rcvClickednum].ROOT_ID,find[s_rcvClickednum].STU_NO,"0");
        QMessageBox::information(this, "提示", "处理完毕", QMessageBox::Ok);
    }
    else {
        QMessageBox::information(this, "提示", "重复操作", QMessageBox::Ok);
    }
}

void rootWindow::on_pushButton_clicked()
{
    qDebug() << "*************************************************" ;
    qDebug() << "***************select root of student rush*******" ;
    qDebug() << "*************************************************" ;
    ui->tableView->clearSpans();

    QStandardItemModel *student_model = new QStandardItemModel();
    student_model->setHorizontalHeaderItem(0, new QStandardItem(QObject::tr("学号")));
    student_model->setHorizontalHeaderItem(1, new QStandardItem(QObject::tr("姓名")));
    student_model->setHorizontalHeaderItem(2, new QStandardItem(QObject::tr("性别")));
    student_model->setHorizontalHeaderItem(3, new QStandardItem(QObject::tr("电话")));
    student_model->setHorizontalHeaderItem(4, new QStandardItem(QObject::tr("住址")));
    //利用setModel()方法将数据模型与QTableView绑定
    ui->tableView->setModel(student_model);
    ui->tableView->setEditTriggers(QAbstractItemView::DoubleClicked); //双击
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows); //成条选
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);//禁止编辑
    /*---------------------------------------------------------------------------------*/


    Student student[50];
    int count = getUserWithClassToListStudent(s_Rootno);
    s_recount = count;
    /********************FILE BEGIN**********************/
    QFile file("./stucount");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
        QTextStream stream(&file);
        for(int i = 0;i < count;i++){
            stream>>student[i].HOLD_NO>>student[i].STU_NO>>student[i].NAME>>student[i].SEC>>student[i].PHONE>>student[i].HOME;
        }
    }
    file.close();
    /********************FILE END************************/
    for(int i=0; i < count; i++){
        QStandardItem *item = new QStandardItem();
        item->setCheckable(true);
        item->setText(QString::number(i));
        item->setCheckState(Qt::Unchecked);
        student_model->setItem(i, 0, new QStandardItem(student[i].STU_NO));
        student_model->setItem(i, 1, new QStandardItem(student[i].NAME));
        if(student[i].SEC == "1"){
            student_model->setItem(i, 2, new QStandardItem("男"));
        }
        else{
            student_model->setItem(i, 2, new QStandardItem("女"));
        }
        student_model->setItem(i, 3, new QStandardItem(student[i].PHONE));
        student_model->setItem(i, 4, new QStandardItem(student[i].HOME));
    }

}

void rootWindow::on_pushButton_1_clicked()
{
    qDebug() << "*************************************************" ;
    qDebug() << "*********find one student of table view**********" ;
    qDebug() << "*************************************************" ;

    QStandardItemModel *student_model = new QStandardItemModel();
    ui->tableView->setModel(student_model);
    student_model->clear();

    student_model->setHorizontalHeaderItem(0, new QStandardItem(QObject::tr("学号")));
    student_model->setHorizontalHeaderItem(1, new QStandardItem(QObject::tr("姓名")));
    student_model->setHorizontalHeaderItem(2, new QStandardItem(QObject::tr("性别")));
    student_model->setHorizontalHeaderItem(3, new QStandardItem(QObject::tr("电话")));
    student_model->setHorizontalHeaderItem(4, new QStandardItem(QObject::tr("住址")));
    Student student[s_recount];
    Student vieStudent;
    int addnum = 0;
    qDebug()<<"on_pushButton_1_clicked.s_recount"<<s_recount;
    QFile file("./stucount");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
        QTextStream stream(&file);
        for(int i = 0;i < s_recount;i++){
            stream>>student[i].HOLD_NO>>student[i].STU_NO>>student[i].NAME>>student[i].SEC>>student[i].PHONE>>student[i].HOME;
            qDebug()<<"open file this is "<<student[i].STU_NO;
        }
    }
    file.close();
    int findit = 0;
    for(int i = 0;i < s_recount;i++){
        qDebug()<<"输出到iv上的统计： "<<student[i].STU_NO;
        if(student[i].STU_NO == ui->lineEdit->text() || student[i].NAME == ui->lineEdit_3->text()){
            qDebug()<<"find it !!!!!!!!!!!!!!!"<<endl;
            findit ++;
            vieStudent.STU_NO = student[i].STU_NO;
            vieStudent.NAME   = student[i].NAME;
            vieStudent.SEC    = student[i].SEC;
            vieStudent.PHONE  = student[i].PHONE;
            vieStudent.HOME   = student[i].HOME;
            break;
        }
    }
    if(findit == 0){
        QMessageBox::information(this, "提示", "没有找到", QMessageBox::Ok);
    }
    QStandardItem *item = new QStandardItem();
    item->setCheckable(true);
    item->setText(0);
    item->setCheckState(Qt::Unchecked);
    student_model->setItem(0, 0, new QStandardItem(vieStudent.STU_NO));
    student_model->setItem(0, 1, new QStandardItem(vieStudent.NAME));
    if(vieStudent.SEC == "1"){
        student_model->setItem(0, 2, new QStandardItem("男"));
    }
    else{
        student_model->setItem(0, 2, new QStandardItem("女"));
    }
    student_model->setItem(0, 3, new QStandardItem(vieStudent.PHONE));
    student_model->setItem(0, 4, new QStandardItem(vieStudent.HOME));
}


void rootWindow::on_pushButton_2_clicked()
{
    int choose;
    Student student;
    choose= QMessageBox::question(this, tr("删除人员"),
                                  QString(tr("确认删除?")),
                                  QMessageBox::Yes | QMessageBox::No);
    if (choose== QMessageBox::Yes) {
        if(!ui->lineEdit->text().isEmpty() && !ui->lineEdit_3->text().isEmpty()){
            getStudentOfStuNo(ui->lineEdit->text(),student);
            if(student.NAME == ui->lineEdit_3->text()){
                deleteUserWithClass(ui->lineEdit->text());
                updatShenQing(s_Rootno, ui->lineEdit->text(), "0");
                QMessageBox::information(this, "提示", "删除成功", QMessageBox::Ok);
            }
            else{
                QMessageBox::information(this, "提示", "学号姓名不匹配", QMessageBox::Ok);
            }
        }
        else{
            QMessageBox::information(this, "提示", "学号或姓名未输入，需要精确操作", QMessageBox::Ok);
        }
    } else if (choose== QMessageBox::No) {}
}
