#ifndef STUDENT_WINDOW_H
#define STUDENT_WINDOW_H

#include <QDialog>
#include <QFileDialog>
#include <QWidget>
/************muzic begin**************/
#include <phonon>
#include <QDebug>
#include <QMessageBox>
#include <QFile>
#include <QDesktopServices> //打开本地文件夹
/************muzic end****************/

/************image begin**************/
#include <QImage>
#include <QPixmap>
#include <QDir>
#include <QSize>
#include <QFileInfo>
#include <QFileInfoList>
#include <QScrollArea>
#include <QGridLayout>
#include <QPainter>
/************image end****************/

/************SELECT STUDENT OF CLASS BEGIN****************/
#include <QStandardItemModel>

/************SELECT STUDENT OF CLASS END******************/
#include "sqlhanshu.h"
namespace Ui {
class Student_window;
}


static QString s_holdno;
static QString s_photoname;
static QImage s_chimage;
static int s_StuReCount;
static int s_StuRelow;

//static int s_rcvClickCount;
class Student_window : public QDialog
{
    Q_OBJECT
signals:
    //登录成功后发射信号
    void sendCount(int count,int row);
private slots:
    void on_toolButton_previous_clicked();//上一首
    void on_toolButton_playpause_clicked();//播放/暂停
    void on_toolButton_stop_clicked();//停止播放
    void on_toolButton_next_clicked();//下一首
    void on_toolButton_open_clicked();//打开
    void on_toolButton_lrcD_clicked();//删除

    void on_pushButton_6_clicked();

public:
    explicit Student_window(QWidget *parent = 0);
    ~Student_window();

    Phonon::MediaObject *audio;//管理媒体源
    Phonon::MediaObject *musicInformationMediaObject;//音乐信息对象
    Phonon::VideoWidget *videoWidget;//
    Phonon::AudioOutput *audioOutput;//连接物理设备
    Phonon::SeekSlider *seekSlider;//实现进度条
    Phonon::VolumeSlider *volumeSlider;//音量调节
    QList<Phonon::MediaSource> sourceList;//播放列表

    QTimer *timer;

    QIcon *iconplay;
    QIcon *iconpause;

    QAction *play;
    QAction *stop;
    QAction *open;
    QAction *sound;
    QAction *exit;
    QAction *remove;
    
    QString s_holderno;
private:
    Ui::Student_window *ui;
private slots:
    void recHolderno(QString holdno);

    void rowDoubleClicked();



/************image begin**************/

    void on_pushButton_3_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_13_clicked();

    void on_pushButton_14_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_clicked();

    void on_pushButton_1_clicked();

    void on_pushButton_11_clicked();

    void on_pushButton_7_clicked();

public:
    QString filename;
    QFileInfoList imgInfoList; //遍历文件
    int index;
    QString path;

    QWidget *centralWidget;

/************image end****************/

};

#endif // STUDENT_WINDOW_H


