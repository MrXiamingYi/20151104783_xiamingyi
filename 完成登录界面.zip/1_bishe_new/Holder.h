#ifndef HOLDER_H
#define HOLDER_H
#include <QString>
class Holder
{
public:
    Holder(QString HOLD_NO="", QString PASSWORD="");

    QString getHold_no() const;
    void setHold_no(const QString &hold_no);

    QString getPasswd() const;
    void setPasswd(const QString &passwd);

public:
    QString HOLD_NO;
    QString PASSWORD;
};


#endif // HOLDER_H
