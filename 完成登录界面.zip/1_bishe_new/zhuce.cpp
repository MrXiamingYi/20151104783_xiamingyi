#include "zhuce.h"
#include "ui_zhuce.h"
#include <QDebug>
zhuce::zhuce(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::zhuce)
{
    ui->setupUi(this);
}

zhuce::~zhuce()
{
    delete ui;
}
QString zhuce_holderno;
QString zhuce_passwd;
QString zhuce_name;
QString zhuce_sec;
QString zhuce_numb;
QString zhuce_phone;
void zhuce::on_pushButton_clicked()
{
    zhuce_holderno =ui->lineEdit_6->text();
    zhuce_passwd   =ui->lineEdit_2->text();
    zhuce_name     =ui->lineEdit_5->text();
    zhuce_sec      =ui->radioButton->isChecked() ? "Man" : "Woman";
    zhuce_numb     =ui->lineEdit_3->text();
    zhuce_phone    =ui->lineEdit_4->text();
    qDebug()<< "~~~~~1~~3~~~4~~~"<<ok_getholder<<endl;

}
