#include "student_window.h"
#include "ui_student_window.h"

Student_window::Student_window(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Student_window)
{
    ui->setupUi(this);
}

Student_window::~Student_window()
{
    delete ui;
}
//显示欢迎弹框
/*
void MainWindow_menu::recUsrname(QString name)
{
    QString str = QString("欢迎你! %1").arg(name);
    ui->label->setText(str);
}
*/
