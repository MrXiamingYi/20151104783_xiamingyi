#ifndef ZHUCE_H
#define ZHUCE_H

#include <QDialog>
#include "sqlhanshu.h"

namespace Ui {
class zhuce;
}

class zhuce : public QDialog
{
    Q_OBJECT
    
public:
    explicit zhuce(QWidget *parent = 0);
    ~zhuce();
    
private slots:
    void on_pushButton_clicked();
signals:
    void send(QString b,QString c);

private:
    Ui::zhuce *ui;
public:
    QString zhuce_holderno;
    QString zhuce_passwd;
    QString zhuce_name;
    QString zhuce_sec;
    QString zhuce_numb;
    QString zhuce_phone;
};

#endif // ZHUCE_H
