#include "sqlhanshu.h"

bool connect_xiasql(const QString &dbName){
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("192.168.1.43");
    db.setDatabaseName(dbName);
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("123456");
    if (!db.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"), db.lastError().text());
        return false;
    }
    else
    {
        QMessageBox::information(0,QObject::tr("Tips"),QObject::tr("连接数据库成功。。！"));
        return true;
    }
}

bool getHolderNo(char *holderno , Holder &holder){

    QSqlQuery query;

    char dbyuju[100] = "";
    sprintf(dbyuju,"select * from ACCOUNT where ACCOUNT.HOLD_NO = \"%s\"",holderno);
    query.exec(dbyuju);
    while(query.next()){
       holder.HOLD_NO = query.value(0).toString();
       holder.PASSWORD = query.value(1).toString();

       qDebug()<<holder.HOLD_NO<<endl;
       qDebug()<<holder.PASSWORD<<endl;
       if(holder.PASSWORD.isEmpty()){
           qDebug() <<"no holder!!! "<<endl;
           return 0;
       }
       else{
           //qDebug() <<holder.HOLD_NO <<" "<<holder.PASSWORD;
           return 1;
       }
    }
    return 0;
}
