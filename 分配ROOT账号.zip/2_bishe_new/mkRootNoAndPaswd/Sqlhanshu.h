#ifndef SQLHANSHU_H
#define SQLHANSHU_H
#include <QApplication>
#include <QtSql>

#include <QDebug>        //输出debug
#include <stdlib.h>
#include <QSqlQuery>
#include <QTime>
#include <QMessageBox>
#include <QApplication>

#include "Root.h"
#include "School.h"
#include "Root.h"
#include "Class.h"
#include "SchoolWithClass.h"
#include "RootWithClass.h"

bool connect_xiasql(const QString &dbName);

int selectClass();

int selectSchool();

bool insertClass(QString CLASS_NAME);

QString insertSchoolWithClass(SchoolWithClass schoolwithclass);

bool insertRootWithClass(RootWithClass rootwithclass);

bool insertRoot(Root root);

bool getRoot(QString rootNo, Root root);
#endif // SQLHANSHU_H

