#ifndef ROOTWITHCLASS_H
#define ROOTWITHCLASS_H
#include <QString>
class RootWithClass
{
public:
    QString ROOT_ID;
    QString SWC_NUNBER;
};

#endif // ROOTWITHCLASS_H
