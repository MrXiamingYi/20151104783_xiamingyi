#ifndef CLASS_H
#define CLASS_H
#include <QString>
class Class
{
public:
    QString ROOT_ID;
    QString CLASS_NAME;
};

#endif // CLASS_H
