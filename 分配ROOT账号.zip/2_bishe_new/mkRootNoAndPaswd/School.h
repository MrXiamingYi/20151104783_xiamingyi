#ifndef SCHOOL_H
#define SCHOOL_H
#include <QString>
class School
{
public:
    QString SCHOOL_ID;
    QString SHCOOL_NAME;
};

#endif // SCHOOL_H
