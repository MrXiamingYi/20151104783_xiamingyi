#ifndef ROOT_H
#define ROOT_H
#include <QString>
class Root
{
public:
    QString ROOT_ID;
    QString ROOT_NAME;
    QString ROOT_PASWD;
    QString PHONE;
};

#endif // ROOT_H
