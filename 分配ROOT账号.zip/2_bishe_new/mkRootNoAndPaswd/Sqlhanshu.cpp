#include "Sqlhanshu.h"


bool connect_xiasql(const QString &dbName){
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("172.20.10.4");
    db.setDatabaseName(dbName);
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("123456");
    if (!db.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"), db.lastError().text());
        return false;
    }
    else
    {
        QMessageBox::information(0,QObject::tr("Tips"),QObject::tr("连接数据库成功。。！"));
        return true;
    }
}

int selectClass(){
    QSqlQuery query;
    Class theClass[50];
    int count = 0;
    QString dbyuju = QString("SELECT * FROM THE_CLASS;");
    query.exec(dbyuju);
    while(query.next()){
        theClass[count].ROOT_ID = query.value(0).toString();
        theClass[count].CLASS_NAME = query.value(1).toString();
        count++;
    }

    QString count_stu[count];
    for(int i = 0 ; i < count;i++){
        count_stu[i] = QString("%1 %2").arg(theClass[i].ROOT_ID).arg(theClass[i].CLASS_NAME);
    }

    QFile file("./selectClass");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
    QTextStream stream(&file);
        for(int j = 0;j < count;j++){
            stream << count_stu[j] << endl;
        }
    }
    file.close();

    return count;
}

int selectSchool(){
    QSqlQuery query;
    School theSchool[50];
    int count = 0;
    QString dbyuju = QString("SELECT * FROM SCHOOL;");
    query.exec(dbyuju);
    while(query.next()){
        theSchool[count].SCHOOL_ID = query.value(0).toString();
        theSchool[count].SHCOOL_NAME = query.value(1).toString();
        count++;
    }

    QString count_stu[count];
    for(int i = 0 ; i < count;i++){
        count_stu[i] = QString("%1 %2").arg(theSchool[i].SCHOOL_ID).arg(theSchool[i].SHCOOL_NAME);
    }

    QFile file("./selectSchool");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
    QTextStream stream(&file);
        for(int j = 0;j < count;j++){
            stream << count_stu[j] << endl;
        }
    }
    file.close();
    return count;
}

bool insertClass(QString CLASS_NAME){
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    QString claNo[6];
    for(int i=0; i<6; i++)
    {
        int test =qrand()%10;
        claNo[i] = QString::number(test, 10);
    }

    QString classNo = QString("%1%2%3%4%5%6").arg(claNo[0]).arg(claNo[1]).arg(claNo[2])
                                             .arg(claNo[3]).arg(claNo[4]).arg(claNo[5]);
    QSqlQuery query;
    QString dbyuju = QString("INSERT INTO THE_CLASS (CLASS_ID,CLASS_NAME) VALUES(\"%1\",\"%2\");").arg(classNo)
            .arg(CLASS_NAME);
    if(query.exec(dbyuju)){
        return 1;
    }
    else{
        return 0;
    }
}

QString insertSchoolWithClass(SchoolWithClass schoolwithclass){
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    QString SWCNo[5];
    for(int i=0; i<5; i++)
    {
        int test =qrand()%10;
        SWCNo[i] = QString::number(test, 10);
    }

    QString SWC_No = QString("%1%2%3%4%5").arg(SWCNo[0]).arg(SWCNo[1]).arg(SWCNo[2])
                                           .arg(SWCNo[3]).arg(SWCNo[4]);
    QSqlQuery query;
    QString dbyuju = QString("INSERT INTO SC_W_CL (SWC_NUNBER,SCHOOL_ID,CLASS_ID) VALUES(\"%1\",\"%2\",\"%3\");")
            .arg(SWC_No).arg(schoolwithclass.SCHOOL_ID).arg(schoolwithclass.CLASS_ID);
    query.exec(dbyuju);
    return SWC_No;
}

bool insertRootWithClass(RootWithClass rootwithclass){
    QSqlQuery query;
    QString dbyuju = QString("INSERT INTO RO_W_CL_SC (ROOT_ID,SWC_NUNBER) VALUES(\"%1\",\"%2\");")
            .arg(rootwithclass.ROOT_ID).arg(rootwithclass.SWC_NUNBER);
    if(query.exec(dbyuju)){
        return 1;
    }
    else{
        return 0;
    }
}

bool insertRoot(Root root){
    QSqlQuery query;
    QString dbyuju = QString("INSERT INTO ROOT_US (ROOT_ID, ROOT_NAME,ROOT_PASWD,PHONE) VALUES(\"%1\",\"%2\",\"%3\",\"%4\");")
            .arg(root.ROOT_ID).arg(root.ROOT_NAME).arg(root.ROOT_PASWD).arg(root.PHONE);
    if(query.exec(dbyuju)){
        return 1;
    }
    else{
        return 0;
    }
}

bool getRoot(QString rootNo,Root root){
    QSqlQuery query;
    QString dbyuju = QString("SELECT * FROM ROOT_US WHERE ROOT_US.ROOT_ID = \"%1\";")
            .arg(rootNo);
    query.exec(dbyuju);
    int count = 0;
    while(query.next()){
        root.ROOT_ID = query.value(0).toString();
        root.ROOT_NAME = query.value(1).toString();
        root.ROOT_PASWD = query.value(1).toString();
        root.PHONE = query.value(1).toString();
        count++;
    }
    if(count > 0){
        return 1;
    }
    else{
        return 0;
    }
}


