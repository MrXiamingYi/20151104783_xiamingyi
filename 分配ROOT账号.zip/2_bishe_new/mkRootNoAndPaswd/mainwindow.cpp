#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_1_clicked()
{
    qDebug()<<"\n-----刷新学校表 begin-----";
    int count = selectSchool();
    School school[count];
    School school2[count];
    int addnum = 0;
    QStringList listSchool;
    QString listSC[count];
    QFile file("./selectSchool");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
        QTextStream stream(&file);
        for(int i = 0;i < count;i++)
        {
            listSC[i] = stream.readLine();
            listSchool=listSC[i].split(QRegExp(" "));
            school[i].SCHOOL_ID = listSchool[0];
            school[i].SHCOOL_NAME = listSchool[1];
        }
    }
    file.close();

    QStandardItemModel *selectSchool = new QStandardItemModel();
    ui->tableView->setModel(selectSchool);

    selectSchool->clear();
    selectSchool->removeRows(0,selectSchool->rowCount());

    ui->tableView->setEditTriggers(QAbstractItemView::SelectedClicked); //单击
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows); //成条选
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);//禁止编辑
    selectSchool->setHorizontalHeaderItem(0, new QStandardItem(QObject::tr("编号")));
    selectSchool->setHorizontalHeaderItem(1, new QStandardItem(QObject::tr("学校")));
    ui->tableView->setColumnWidth(0, 60);
    ui->tableView->setColumnWidth(1, 128);

    for(int i = 0;i < count;i++){
        if(ui->lineEdit_1->text() != NULL){
            if(school[i].SHCOOL_NAME == ui->lineEdit_1->text()){
                school2[addnum].SCHOOL_ID = school[i].SCHOOL_ID;
                school2[addnum].SHCOOL_NAME = school[i].SHCOOL_NAME;
                addnum++;
                continue;
            }
        }
        else{
            school2[addnum].SCHOOL_ID = school[i].SCHOOL_ID;
            school2[addnum].SHCOOL_NAME = school[i].SHCOOL_NAME;
            addnum++;
        }
    }

    for(int i = 0 ; i < addnum; i++){
        QStandardItem *item = new QStandardItem();
        item->setCheckable(true);
        item->setText(QString::number(i));
        item->setCheckState(Qt::Unchecked);
        selectSchool->setItem(i, 0, new QStandardItem(school2[i].SCHOOL_ID));
        selectSchool->setItem(i, 1, new QStandardItem(school2[i].SHCOOL_NAME));
    }
    qDebug()<<" -----刷新学校表 end-----\n";
}

void MainWindow::on_pushButton_2_clicked()
{
    qDebug()<<" \n -----刷新班级表 -----";

    int count = selectClass();
    Class cla[count];
    Class cla2[count];
    QStringList listClass;
    QString listCL[count];
    QFile file("./selectClass");
    int addnum = 0;
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
        QTextStream stream(&file);
        for(int i = 0;i < count;i++)
        {
            listCL[i] = stream.readLine();
            listClass=listCL[i].split(QRegExp(" "));
            cla[i].ROOT_ID = listClass[0];
            cla[i].CLASS_NAME = listClass[1];
        }
    }
    file.close();

    QStandardItemModel *selectClass = new QStandardItemModel();
    ui->tableView_2->setModel(selectClass);

    selectClass->clear();
    selectClass->removeRows(0,selectClass->rowCount());

    ui->tableView_2->setEditTriggers(QAbstractItemView::SelectedClicked); //单击
    ui->tableView_2->setSelectionBehavior(QAbstractItemView::SelectRows); //成条选
    ui->tableView_2->setEditTriggers(QAbstractItemView::NoEditTriggers);//禁止编辑
    selectClass->setHorizontalHeaderItem(0, new QStandardItem(QObject::tr("编号")));
    selectClass->setHorizontalHeaderItem(1, new QStandardItem(QObject::tr("班级")));
    ui->tableView_2->setColumnWidth(0, 60);
    ui->tableView_2->setColumnWidth(1, 128);

    for(int i = 0;i < count;i++){
        if(ui->lineEdit_2->text() != NULL){
            if(cla[i].CLASS_NAME == ui->lineEdit_2->text()){
                cla2[addnum].ROOT_ID = cla[i].ROOT_ID;
                cla2[addnum].CLASS_NAME = cla[i].CLASS_NAME;
                addnum++;
                continue;
            }
        }
        else{
            cla2[addnum].ROOT_ID = cla[i].ROOT_ID;
            cla2[addnum].CLASS_NAME = cla[i].CLASS_NAME;
            addnum++;
        }
    }

    for(int i = 0 ; i < addnum; i++){
        QStandardItem *item = new QStandardItem();
        item->setCheckable(true);
        item->setText(QString::number(i));
        item->setCheckState(Qt::Unchecked);
        selectClass->setItem(i, 0, new QStandardItem(cla2[i].ROOT_ID));
        selectClass->setItem(i, 1, new QStandardItem(cla2[i].CLASS_NAME));
    }

    qDebug()<<"  -----刷新班级表 -----\n";
}

void MainWindow::on_pushButton_8_clicked()
{
    qDebug()<<" \n -----创建班级 -----";
    if(!ui->lineEdit_9->text().isEmpty()){
        bool ok = insertClass(ui->lineEdit_9->text());
        if(ok = 1){
            QMessageBox::information(this, "提示", "新加班级成功", QMessageBox::Ok);
        }
        else{
            QMessageBox::information(this, "提示", "新加班级失败", QMessageBox::Ok);
        }
    }
    else{
        QMessageBox::information(this, "提示", "未输入内容", QMessageBox::Ok);
    }
    qDebug()<<"  -----创建班级 -----\n";
}

void MainWindow::on_pushButton_3_clicked()
{
    qDebug()<<" \n -----插入root用户 -----";
    SchoolWithClass schwclas;
    RootWithClass rootWhinclass;
    Root root;

    if(!ui->lineEdit_3->text().isEmpty() && !ui->lineEdit_4->text().isEmpty() &&
            !ui->lineEdit_5->text().isEmpty() &&!ui->lineEdit_6->text().isEmpty() &&
            !ui->lineEdit_7->text().isEmpty() && !ui->lineEdit_8->text().isEmpty())
    {
        if(!getRoot(ui->lineEdit_5->text(),root)){

            schwclas.SWC_NUNBER = "";
            schwclas.SCHOOL_ID = ui->lineEdit_3->text();
            schwclas.CLASS_ID = ui->lineEdit_4->text();

            QString SCwCLNo = insertSchoolWithClass(schwclas);
            rootWhinclass.SWC_NUNBER = SCwCLNo;
            rootWhinclass.ROOT_ID = ui->lineEdit_5->text();

            root.ROOT_ID = ui->lineEdit_5->text();
            root.ROOT_NAME = ui->lineEdit_7->text();
            root.ROOT_PASWD = ui->lineEdit_6->text();
            root.PHONE = ui->lineEdit_8->text();

            if(insertRoot(root)){
                if(insertRootWithClass(rootWhinclass)){
                    QMessageBox::information(this, "提示", "创建完毕", QMessageBox::Ok);
                }
                else{
                    QMessageBox::information(this, "提示", "创建失败", QMessageBox::Ok);
                }
            }
            else{
                return ;
            }
        }
        else{
            QMessageBox::information(this, "提示", "帐号重复", QMessageBox::Ok);
        }
    }
    else{
        QMessageBox::information(this, "提示", "缺少输入", QMessageBox::Ok);
    }
    qDebug()<<"  -----插入root用户 -----\n";
}
