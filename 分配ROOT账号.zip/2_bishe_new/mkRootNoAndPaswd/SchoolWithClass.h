#ifndef SCHOOLWITHCLASS_H
#define SCHOOLWITHCLASS_H
#include <QString>
class SchoolWithClass
{
public:
    QString SWC_NUNBER;
    QString SCHOOL_ID;
    QString CLASS_ID;
};

#endif // SCHOOLWITHCLASS_H
