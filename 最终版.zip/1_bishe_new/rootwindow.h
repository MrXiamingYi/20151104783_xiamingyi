#ifndef ROOTWINDOW_H
#define ROOTWINDOW_H

#include <QDialog>
#include <phonon>
#include <QDebug>
#include <QMessageBox>
#include <QFile>
#include <QDesktopServices> //打开本地文件夹
#include <QFileDialog>
#include "sqlhanshu.h"
#include "gonggongku.h"

static QString s_Rootno;
static int s_rcvClickednum;
static int s_rcvClickedCount;
static int s_recount;
namespace Ui {
class rootWindow;
}

class rootWindow : public QDialog
{
    Q_OBJECT
private slots:
    void recRootno(QString rootno);
    void rowClicked();
private slots:
    void on_toolButton_previous_clicked();//上一首
    void on_toolButton_playpause_clicked();//播放/暂停
    void on_toolButton_stop_clicked();//停止播放
    void on_toolButton_next_clicked();//下一首
    void on_toolButton_open_clicked();//打开
    void on_toolButton_lrcD_clicked();//删除
    void on_pushButton_24_clicked();

    void on_pushButton_25_clicked();

    void on_pushButton_27_clicked();

    void on_pushButton_clicked();

    void on_pushButton_1_clicked();


    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

public:
    explicit rootWindow(QWidget *parent = 0);
    ~rootWindow();
    Phonon::MediaObject *audio;//管理媒体源
    Phonon::MediaObject *musicInformationMediaObject;//音乐信息对象
    Phonon::VideoWidget *videoWidget;//
    Phonon::AudioOutput *audioOutput;//连接物理设备
    Phonon::SeekSlider *seekSlider;//实现进度条
    Phonon::VolumeSlider *volumeSlider;//音量调节
    QList<Phonon::MediaSource> sourceList;//播放列表

    QTimer *timer;

    QIcon *iconplay;
    QIcon *iconpause;

    QAction *play;
    QAction *stop;
    QAction *open;
    QAction *sound;
    QAction *exit;
    QAction *remove;

private:
    Ui::rootWindow *ui;
};

#endif // ROOTWINDOW_H
