#include <QtGui/QApplication>
#include <QTextCodec>
#include <QDesktopWidget>
#include "mainwindow.h"
#include "sqlhanshu.h"

int main(int argc, char *argv[])
{
    // 设置中文输出  begin
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF8"));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF8"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF8"));
    // 设置中文输出  end



    //查看QT接口 begin
    QApplication a(argc, argv);
    qDebug()<<"begin to link sql:";
    QStringList drivers = QSqlDatabase::drivers();
    foreach(QString driver,drivers)
    qDebug() <<driver;

    connect_xiasql("xiaoyoulu");

    //查看中文接口 end
    MainWindow w;
    w.move ((QApplication::desktop()->width() - w.width())/2,(QApplication::desktop()->height() - w.height())/2);
    w.setWindowTitle("登录界面");

    w.show();
    
    return a.exec();
}
