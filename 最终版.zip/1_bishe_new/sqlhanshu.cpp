#include "sqlhanshu.h"

bool connect_xiasql(const QString &dbName){
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("172.20.10.4");
    db.setDatabaseName(dbName);
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("123456");
    if (!db.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"), db.lastError().text());
        return false;
    }
    else
    {
        QMessageBox::information(0,QObject::tr("Tips"),QObject::tr("连接数据库成功。。！"));
        return true;
    }
}

bool getStudent(char *HOLD_NO,Student &student){
    qDebug()<<"goto getStudent "<<endl<<HOLD_NO;

    QSqlQuery query;
    char dbyuju[500] = "";
    sprintf(dbyuju,"select * from STUDENT WHERE STUDENT.HOLD_NO = \"%s\"",HOLD_NO);
    query.exec(dbyuju);
    qDebug()<<"select student OK  ";
    while(query.next()){
       student.HOLD_NO = QStoCH(query.value(0).toString());
       student.STU_NO  = query.value(1).toString();
       student.NAME    = query.value(2).toString();
       student.SEC     = query.value(3).toString();
       student.PHONE   = query.value(4).toString();
       student.HOME    = query.value(5).toString();

       if(student.HOLD_NO.isEmpty()||
               student.STU_NO.isEmpty()||
               student.NAME  .isEmpty()||
               student.SEC   .isEmpty()){
           qDebug() <<"Dont find Student " ;
           return 0;
       }
       else{
           return 1;
       }
    }
    return 0;
}

bool getHolderNo(char *holderno , Holder &holder){


    qDebug() << "*****************************************" ;
    qDebug() << "***************getHolderNo***************" ;
    qDebug() << "*****************************************" ;
    QSqlQuery query;

    char dbyuju[100] = "";
    sprintf(dbyuju,"select * from ACCOUNT where ACCOUNT.HOLD_NO = \"%s\"",holderno);
    query.exec(dbyuju);
    while(query.next()){
       holder.HOLD_NO = query.value(0).toString();
       holder.PASSWORD = query.value(1).toString();

       qDebug()<<holder.HOLD_NO ;
       qDebug()<<holder.PASSWORD ;
       if(holder.PASSWORD.isEmpty()){
           qDebug() <<"no holder!!! " ;
           return 0;
       }
       else{
           //qDebug() <<holder.HOLD_NO <<" "<<holder.PASSWORD;
           return 1;
       }
    }
    return 0;
}

bool insertHolder(Holder holder){
    QSqlQuery query;
    Holder l_holder;
    char l_holderno[7] = "";

    char dbyuju[500] = "";
    sprintf(dbyuju,"INSERT INTO ACCOUNT (HOLD_NO,PASSWORD) VALUES(\"%s\",\"%s\")",QStoCH(holder.HOLD_NO),QStoCH(holder.PASSWORD));

    qDebug()<<"holderno and paswd"<<QStoCH(holder.HOLD_NO)<<QStoCH(holder.PASSWORD) ;
    qDebug()<<dbyuju ;
    query.exec(dbyuju);
    strcpy(l_holderno,QStoCH(holder.HOLD_NO));

    if(getHolderNo(l_holderno,l_holder)){
        qDebug()<<"插入成功" ;
        return 1;
    }
    else
        return 0;
}

bool insertStudent(char *holderno,char *numb,char *name,char *sec,char *phone,char *jia){
    QSqlQuery query;
    Student l_student;

    char dbyuju[500] = "";
    sprintf(dbyuju,"INSERT INTO STUDENT (HOLD_NO,STU_NO,NAME,SEC,PHONE,HOME) VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\");",holderno,numb,name,sec,phone,jia);
    query.exec(dbyuju);
    bool ok_no = getStudent(holderno,l_student);
    if(ok_no){
        qDebug()<<"插入成功" ;
        return 1;
    }
    else
        return 0;
}

bool updatStudent(QString name, QString sex,QString phone,QString home,QString holdno){
    QSqlQuery query;
    Student student;
    QString dbyuju = QString("UPDATE STUDENT SET STUDENT.NAME = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(name).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.SEC = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(sex).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.PHONE = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(phone).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.HOME = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(home).arg(holdno);
    query.exec(dbyuju);

    getStudent(QStoCH(holdno),student);
    if(strcmp(QStoCH(student.NAME),QStoCH(name)) == 0 && strcmp(QStoCH(student.SEC),QStoCH(sex)) == 0 &&
            strcmp(QStoCH(student.HOME),QStoCH(home)) == 0 && strcmp(QStoCH(student.PHONE),QStoCH(phone)) == 0 ){
        return 1;
    }
    else
        return 0;
}


int selectStudentAndClass(QString holdno){

    qDebug()<<"\n\n-----into selectStudentAndClass  OK  -----";
    Student find;
    Student l_student[50];
    int recount;
    getStudent(QStoCH(holdno),find);
    QSqlQuery query;
    QString l_stu_no;
    int count = 0 ;
    QString dbyuju1 = QString("SELECT US_W_CL.STU_NO FROM US_W_CL WHERE US_W_CL.SWC_NUNBER = (SELECT US_W_CL.SWC_NUNBER FROM US_W_CL WHERE US_W_CL.STU_NO = \"%1\")")
            .arg(find.STU_NO);
    qDebug()<<"select US_W_CL.SWC_NUNBER sql:"<<dbyuju1;
    query.exec(dbyuju1);
    qDebug()<<"select US_W_CL.SWC_NUNBER OK:";
    for(int i = 0;i < 50;i++){
        if(!query.next()){
            break;
        }
        l_stu_no = query.value(0).toString();
        if(l_stu_no.isEmpty()){
            qDebug() <<"select US_W_CL.l_stu_no ERROR " ;
            return 0;
        }
        else{
            qDebug() <<"select US_W_CL.l_stu_no is :"<<l_stu_no ;
            if(getStudentOfStuNo(l_stu_no,l_student[count])){
                qDebug()<<"selectStudentAndClass.getStudentOfStuNo find it,\nl_student.HOLD_NO is :"<<l_student[count].HOLD_NO;
            }
            else{
                qDebug()<<"selectStudentAndClass.getStudentOfStuNo don't find it";
            }
            count ++;
        }
    }
    recount = count;
    qDebug()<<"selectStudentAndClass.count is :"<<count<<" and "<<recount;

    for(int i = 0 ; i < recount ; i++){
        qDebug()<<"selectStudentAndClass.getStudentOfStuNo find it,l_student.HOLD_NO is :"<<l_student[i].HOLD_NO;
    }
    QString count_stu[count];
    for(int i = 0 ; i < count;i++){
        if(l_student[i].PHONE.isEmpty()){
            l_student[i].PHONE = "空";
        }
        if(l_student[i].HOME.isEmpty()){
            l_student[i].HOME = "空";

        }
        count_stu[i] = QString("%1 %2 %3 %4 %5 %6").arg(l_student[i].HOLD_NO).arg(l_student[i].STU_NO).arg(l_student[i].NAME).arg(l_student[i].SEC).arg(l_student[i].PHONE).arg(l_student[i].HOME);
    }
    QFile file("./stucount");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
    QTextStream stream(&file);
        for(int j = 0;j < count;j++){
            stream << count_stu[j] << endl;
            qDebug()<<"count_stu["<<j<<"] is "<<count_stu[j];
        }
    }
    file.close();
    qDebug()<<"-----into selectStudentAndClass  end  -----\n";
    return recount;
}


bool getStudentOfStuNo(QString STU_NO,Student &student){
    qDebug()<<"\n-----into getStudentOfStuNo ok-----";
    qDebug()<<"getStudentOfStuNo.STU_NO is "<<STU_NO;
    QSqlQuery query;
    QString dbyuju = QString("SELECT * FROM STUDENT WHERE STUDENT.STU_NO = \"%1\";").arg(STU_NO);
    qDebug()<<"getStudentOfStuNo sql is"<<dbyuju;
    query.exec(dbyuju);
    qDebug()<<"getStudentOfStuNo.query.exec(dbyuju) OK  ";
    //qDebug()<<"getStudentOfStuNo.query.next() is "<<query.next();
    while(query.next()){
       student.HOLD_NO = query.value(0).toString();
       student.STU_NO  = query.value(1).toString();
       student.NAME    = query.value(2).toString();
       student.SEC     = query.value(3).toString();
       student.PHONE   = query.value(4).toString();
       student.HOME    = query.value(5).toString();
       qDebug()<<"getStudentOfStuNo.student.HOLD_NO is"<<student.HOLD_NO;
       qDebug()<<"getStudentOfStuNo.student.STU_NO  is"<<student.STU_NO;
       qDebug()<<"getStudentOfStuNo.student.NAME    is"<<student.NAME;
       qDebug()<<"getStudentOfStuNo.student.SEC     is"<<student.SEC;
       if(student.HOLD_NO.isEmpty()||
               student.STU_NO.isEmpty()||
               student.NAME  .isEmpty()||
               student.SEC   .isEmpty()){
           qDebug() <<"Dont find Student " ;
           qDebug()<<"-----into getStudentOfStuNo end -----\n";
           return 0;
       }
       else{
           qDebug()<<"-----into getStudentOfStuNo end -----\n";
           return 1;
       }
    }
    qDebug()<<"-----into getStudentOfStuNo end -----\n";
    return 0;
}

int getSC_W_CL(){
    qDebug()<<"\n\n-----into getSC_W_CL  OK  -----";
    SC_W_CL find[50];
    QSqlQuery query;
    int count = 0 ;
    QString dbyuju1 = QString("SELECT SC_W_CL.SWC_NUNBER,SCHOOL.SHCOOL_NAME,THE_CLASS.CLASS_NAME FROM SC_W_CL,SCHOOL,THE_CLASS WHERE SC_W_CL.SCHOOL_ID = SCHOOL.SCHOOL_ID AND SC_W_CL.CLASS_ID = THE_CLASS.CLASS_ID;");
    query.exec(dbyuju1);
    qDebug()<<"getSC_W_CL.query.exec(dbyuju1);OK:";

    for(int i = 0;i < 50;i++){
        if(!query.next()){
            break;
        }
        find[i].num = query.value(0).toString();
        find[i].school_name = query.value(1).toString();
        find[i].class_name = query.value(2).toString();
        qDebug()<<"查询出来的结果为："<<find[i].num<<find[i].school_name<<find[i].class_name;
        if(find[i].num.isEmpty()){
            qDebug() <<"select US_W_CL.l_stu_no ERROR " ;
            return 0;
        }
        count++;
    }
    for(int i = 0 ; i < count ; i++){
        qDebug()<<"selectStudentAndClass.getStudentOfStuNo find it,l_student.HOLD_NO is :"<<find[i].num;
    }
    QString addstr[count];
    for(int i = 0 ; i < count;i++){
        addstr[i] = QString("%1 %2 %3").arg(find[i].num).arg(find[i].school_name).arg(find[i].class_name);
        qDebug()<<"链接起来的字符串为："<<addstr[i];
    }

    QFile file("./SCWCL");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
    QTextStream stream(&file);
        for(int j = 0;j < count;j++){
            stream << addstr[j] << endl;
            qDebug()<<"写入文件里面的字符串内容为："<<addstr[j];
        }
    }
    file.close();
    qDebug()<<"-----into selectStudentAndClass  end  -----\n";



    return count;
}

int insertShenQing(QString stu_no,QString sc_w_cl_no,QString &root_no,QString biaozhi){
    qDebug()<<"\n\n-----into insertShenQing  OK  -----";
    QSqlQuery query;
    QString rootNo;
    QString dbyuju = QString("SELECT * FROM RO_W_CL_SC WHERE RO_W_CL_SC.SWC_NUNBER = \"%1\";")
            .arg(sc_w_cl_no);
    query.exec(dbyuju);
    while(query.next()){
       rootNo = query.value(0).toString();
    }
    root_no = rootNo;
    qDebug()<<"insertShenQing.root_no is "<<rootNo;
    qDebug()<<"insertShenQing.stu_no  is "<<stu_no;
    qDebug()<<"begin going getShenQing -->-->-->";
    int flag = getShenQing(stu_no,rootNo);
    qDebug()<<"reback insertShenQing -->-->-->";
    qDebug()<<"insertShenQing.return getShenQing.flag  is "<<flag;

    if(flag == 0){
        //被拒绝
        qDebug()<<"-----out getShenQing  OK  -----\n";
        return 0;
    }
    else if(flag == 1){
        //已经加入
        qDebug()<<"-----into getShenQing  OK  -----\n";
        return 1;
    }
    else if(flag == 2){
        //等待被批准
        qDebug()<<"-----into getShenQing  OK  -----\n";
        return 2;
    }
    else if (flag == 3){
        QSqlQuery insert;
        QString dblastyuju = QString("INSERT INTO SHENQING (ROOT_ID,STU_NO,FLAG) VALUES(\"%1\",\"%2\",\"%3\");")
                    .arg(rootNo).arg(stu_no).arg(biaozhi);
        qDebug()<<"insertShenQing instert is "<<dblastyuju;
        insert.exec(dblastyuju);
        if(getShenQing(stu_no,rootNo) == 2){
            qDebug()<<"-----into getShenQing  OK  -----\n";
            return 3;
        }
    }
    else {
        return -1;
    }
}
int getShenQing(QString stu_no,QString root_id){
    qDebug()<<"\n\n-----into getShenQing  OK  -----";
    qDebug()<<" get getShenQing.root_no is "<<root_id;
    qDebug()<<" get getShenQing.stu_no  is "<<stu_no;
    QSqlQuery query;
    ShenQing shenqing;
    QString dbyuju = QString("SELECT * FROM SHENQING WHERE SHENQING.ROOT_ID = \"%1\" AND SHENQING.STU_NO = \"%2\";")
            .arg(root_id).arg(stu_no);
    query.exec(dbyuju);
    while(query.next()){
        shenqing.ROOT_ID = query.value(0).toString();
        shenqing.STU_NO = query.value(1).toString();
        shenqing.FLAG = query.value(2).toString();
    }
    qDebug()<<"getShenQing.shenqing.ROOT_ID"<< shenqing.ROOT_ID;
    qDebug()<<"getShenQing.shenqing.STU_NO "<< shenqing.STU_NO;
    qDebug()<<"getShenQing.shenqing.FLAG   "<< shenqing.FLAG;
    if(shenqing.FLAG == NULL){
        qDebug()<<"-----out getShenQing  OK  -----\n";
        //可以申请
        return 3;
    }
    else if(shenqing.FLAG == "1"){
        qDebug()<<"-----out getShenQing  OK  -----\n";
        //已经加入
        return 1;
    }
    else if(shenqing.FLAG == "2"){
        qDebug()<<"-----out getShenQing  OK  -----\n";
        //已经申请，正在等待
        return 2;
    }
    else if(shenqing.FLAG == "0"){
        qDebug()<<"-----out getShenQing  OK  -----\n";
        //已经拒绝了
        return 0;
    }
    qDebug()<<"-----out getShenQing  OK  -----\n";
    return -1;
}
bool deleteShenQing(QString stu_no,QString root_id){
    qDebug()<<"\n\n-----into deleteShenQing  OK  -----";
    QSqlQuery query;
    QString dbyuju = QString("DELETE FROM  SHENQING WHERE SHENQING.ROOT_ID = \"%1\" AND SHENQING.STU_NO = \"%2\";")
            .arg(root_id).arg(stu_no);
    query.exec(dbyuju);

    if(getShenQing(stu_no,root_id) == 1){
        qDebug()<<"\n\n-----out deleteShenQing  OK  -----";
        return 1;
    }
    else{
        qDebug()<<"\n\n-----into deleteShenQing  OK  -----";
        return 0;
    }
}

bool getRootNo(char *rootno , Root &root){
    qDebug() << "*****************************************" ;
    qDebug() << "***************getRootNo*****************" ;
    qDebug() << "*****************************************" ;
    QSqlQuery query;

    char dbyuju[100] = "";
    sprintf(dbyuju,"select * from ROOT_US where ROOT_US.ROOT_ID = \"%s\"",rootno);
    query.exec(dbyuju);
    while(query.next()){
       root.ROOT_ID = query.value(0).toString();
       root.ROOT_NAME = query.value(1).toString();
       root.ROOT_PASWD = query.value(2).toString();
       root.PHONE = query.value(3).toString();
       if(root.ROOT_PASWD.isEmpty()){
           return 0;
       }
       else{
           return 1;
       }
    }
    return 0;
}

int selectShenqingOfRoot(char *rootno){
    qDebug() << "*****************************************" ;
    qDebug() << "**********selectShenqingOfRoot***********" ;
    qDebug() << "*****************************************" ;
    QSqlQuery query;
    int count = 0;
    ShenQing shenqing[51];
    char dbyuju[100] = "";
    sprintf(dbyuju,"SELECT * FROM SHENQING WHERE SHENQING.ROOT_ID = \"%s\";",rootno);
    query.exec(dbyuju);
    while(query.next()){
       shenqing[count].ROOT_ID = query.value(0).toString();
       shenqing[count].STU_NO = query.value(1).toString();
       shenqing[count].FLAG = query.value(2).toString();
       count++;
    }
    QString addstr[count];
    for(int i = 0 ; i < count;i++){
        addstr[i] = QString("%1 %2 %3").arg(shenqing[i].ROOT_ID).arg(shenqing[i].STU_NO).arg(shenqing[i].FLAG);
        qDebug()<<"链接起来的字符串为："<<addstr[i];
    }

    QFile file("./rootOfShenqingByStudent");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
    QTextStream stream(&file);
        for(int j = 0;j < count;j++){
            stream << addstr[j] << endl;
            qDebug()<<"写入文件里面的字符串内容为："<<addstr[j];
        }
    }
    file.close();

    return count;
}

void insertUserWithClass(QString STU_NO,QString SWC_NUNBER){
    qDebug() << "*****************************************" ;
    qDebug() << "**********insertUserWithClass***********" ;
    qDebug() << "*****************************************" ;
    QSqlQuery query;
    QString dbyuju = QString("INSERT INTO US_W_CL (STU_NO,SWC_NUNBER) VALUES(\"%1\",\"%2\");")
            .arg(STU_NO).arg(SWC_NUNBER);
    qDebug()<<"insertUserWithClass dbyuju is "<<dbyuju;
    query.exec(dbyuju);
}

bool getRootWhihClass(QString RootNo,QString &SWC_NUMBER){
    QSqlQuery query;
    QString dbyuju = QString("SELECT * FROM RO_W_CL_SC WHERE RO_W_CL_SC.ROOT_ID = \"%1\";")
            .arg(RootNo);
    query.exec(dbyuju);
    while(query.next()){
       SWC_NUMBER = query.value(1).toString();
       if(SWC_NUMBER.isEmpty()){
           return 0;
       }
       else{
           return 1;
       }
    }
    return 0;
}

bool updatShenQing(QString RootNo,QString StudentNo,QString gengFlag){
    QSqlQuery query;

    QString dbyuju = QString("UPDATE SHENQING SET SHENQING.FLAG = \"%1\" WHERE SHENQING.ROOT_ID = \"%2\" AND SHENQING.STU_NO = \"%3\";")
            .arg(gengFlag).arg(RootNo).arg(StudentNo);
    query.exec(dbyuju);

    int ChuliBiaozhi = getShenQing(StudentNo,RootNo);
    QString StringBiaozhi = QString::number(ChuliBiaozhi);
    if(StringBiaozhi == gengFlag){
        return 1;
    }
    else {
        return 0;
    }
}

bool getRootOfClass(char *rootno , QString &SWC_NUNBER){
    QSqlQuery query;

    QString dbyuju = QString("SELECT * FROM RO_W_CL_SC WHERE RO_W_CL_SC.ROOT_ID = \"%1\" ;")
            .arg(rootno);
    query.exec(dbyuju);

    while(query.next()){
       SWC_NUNBER = query.value(1).toString();
       if(SWC_NUNBER.isEmpty()){
           return 0;
       }
       else{
           return 1;
       }
    }
    return 0;
}

int getUserWithClassToListStudent(QString rootno){
    qDebug()<<"\n\n-----into getUserWithClassToListStudent  OK  -----";

    Student l_student[50];
    QString student;
    int recount;
    QSqlQuery studentNo;
    QString l_stu_no;
    int count = 0 ;
    QString sqlStudentNo = QString("SELECT US_W_CL.STU_NO FROM US_W_CL WHERE US_W_CL.SWC_NUNBER = (SELECT RO_W_CL_SC.SWC_NUNBER FROM RO_W_CL_SC WHERE RO_W_CL_SC.ROOT_ID = \"%1\");")
            .arg(rootno);
    qDebug()<<"select getUserWithClassToListStudent.SWC_NUNBER sql:"<<sqlStudentNo;
    studentNo.exec(sqlStudentNo);
    qDebug()<<"select getUserWithClassToListStudent.SWC_NUNBER OK:";
    for(int i = 0;i < 50;i++){
        if(!studentNo.next()){
            break;
        }
        student = studentNo.value(0).toString();
        if(student.isEmpty()){
            qDebug() <<"select getUserWithClassToListStudent.l_stu_no ERROR " ;
            return 0;
        }
        else{
            qDebug() <<"select getUserWithClassToListStudent.l_stu_no is :"<<l_stu_no ;
            if(getStudentOfStuNo(student,l_student[count])){
                qDebug()<<"getUserWithClassToListStudent.getStudentOfStuNo find it,\nl_student.HOLD_NO is :"<<l_student[count].HOLD_NO;
            }
            else{
                qDebug()<<"getUserWithClassToListStudent.getStudentOfStuNo don't find it";
            }
            count ++;
        }
    }
    recount = count;
    qDebug()<<"getUserWithClassToListStudent.count is :"<<count<<" and "<<recount;

    for(int i = 0 ; i < recount ; i++){
        qDebug()<<"getUserWithClassToListStudent.getStudentOfStuNo find it,l_student.HOLD_NO is :"<<l_student[i].HOLD_NO;
    }
    QString count_stu[recount];
    for(int i = 0 ; i < count;i++){
        if(l_student[i].PHONE.isEmpty()){
            l_student[i].PHONE = "空";
        }
        if(l_student[i].HOME.isEmpty()){
            l_student[i].HOME = "空";
        }
        count_stu[i] = QString("%1 %2 %3 %4 %5 %6").arg(l_student[i].HOLD_NO).arg(l_student[i].STU_NO).arg(l_student[i].NAME).arg(l_student[i].SEC).arg(l_student[i].PHONE).arg(l_student[i].HOME);
    }
    QFile file("./stucount");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
    QTextStream stream(&file);
        for(int j = 0;j < count;j++){
            stream << count_stu[j] << endl;
            qDebug()<<"count_stu["<<j<<"] is "<<count_stu[j];
        }
    }
    file.close();
    qDebug()<<"-----into selectStudentAndClass  end  -----\n";
    return recount;
}

bool deleteUserWithClass(QString stu_no){
    QSqlQuery query;

    QString dbyuju = QString("DELETE FROM  US_W_CL WHERE US_W_CL.STU_NO = \"%1\";")
            .arg(stu_no);
    query.exec(dbyuju);
    return 1;
}

bool findStuIsOnClass(QString stu_no){
    QSqlQuery query;
    QString SWC_NUNBER;
    QString dbyuju = QString("SELECT * FROM SHENQING WHERE SHENQING.STU_NO =  \"%1\";")
            .arg(stu_no);
    query.exec(dbyuju);
    while (query.next()){
        SWC_NUNBER = query.value(2).toString();
        if(SWC_NUNBER == "1"){
            return 0;
        }
        else{
            continue;
        }
    }
    return 1;
}
bool updateHolder(Holder holderNo){
    QSqlQuery query;
    QString dbyuju = QString("UPDATE ACCOUNT SET ACCOUNT.PASSWORD = \"%1\" WHERE ACCOUNT.HOLD_NO = \"%2\";")
            .arg(holderNo.PASSWORD).arg(holderNo.HOLD_NO);
    qDebug()<<"updateHolder :"<<dbyuju;
    if(query.exec(dbyuju)){
        return 1;
    }
    else{
        return 0;
    }
}
bool updateRoot(Root root){
    QSqlQuery query;
    QString dbyuju = QString("UPDATE ROOT_US SET ROOT_US.ROOT_PASWD = \"%1\" WHERE ROOT_US.ROOT_ID = \"%2\";")
            .arg(root.ROOT_PASWD).arg(root.ROOT_ID);
    if(query.exec(dbyuju)){
        return 1;
    }
    else{
        return 0;
    }
}
