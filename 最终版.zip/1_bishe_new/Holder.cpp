#include "Holder.h"

Holder::Holder(QString hold_no,
               QString passwd):
               HOLD_NO(hold_no),
               PASSWORD(passwd)
{

}
void Holder::setHold_no(const QString &holdno)
{
    HOLD_NO = holdno;
}

QString Holder::getHold_no() const
{
    return HOLD_NO;
}

void Holder::setPasswd(const QString &paswd)
{
    PASSWORD = paswd;
}
QString Holder::getPasswd() const
{
    return PASSWORD;
}
