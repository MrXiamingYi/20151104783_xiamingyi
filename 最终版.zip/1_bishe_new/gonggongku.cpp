
#include "gonggongku.h"

char * QStoCH(QString filename){
    QString str(filename);
    QByteArray cpath = str.toLocal8Bit();
    char *p = (char *)malloc(filename.length());
    p = cpath.data();
    return p;
}
