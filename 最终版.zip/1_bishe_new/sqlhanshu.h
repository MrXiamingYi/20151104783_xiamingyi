#ifndef SQLHANSHU_H
#define SQLHANSHU_H

#include "mainwindow.h"
#include <QApplication>
#include <QtSql>

#include <QDebug>        //输出debug
#include <QMessageBox>
#include <stdlib.h>
#include <Holder.h>
#include "Student.h"
#include "SC_W_CL.h"
#include "Root.h"
#include "ShenQing.h"
#include "student_window.h"
#include "ui_student_window.h"
bool connect_xiasql(const QString &dbName);

bool getHolderNo(char *holderno , Holder &holder);

bool getRootNo(char *rootno , Root &root);

bool insertHolder(Holder holder);

void insertUserWithClass(QString STU_NO,QString SWC_NUNBER);

bool insertStudent(char *zhuce_holderno,char *numb,char *name,char *sec,char *phone,char *jia);

bool getStudent(char *HOLD_NO,Student &student);

bool getStudentOfStuNo(QString STU_NO,Student &student);

bool getRootWhihClass(QString RootNo,QString &SWC_NUMBER);

bool updatStudent(QString name, QString sex,QString phone,QString home,QString holdno);

bool updatShenQing(QString RootNo,QString StudentNo, QString gengFlag);

int selectStudentAndClass(QString holdno);

int getSC_W_CL();

int insertShenQing(QString stu_no,QString sc_w_cl_no, QString &root_no,QString biaozhi);

int getShenQing(QString stu_no,QString root_id);

bool deleteShenQing(QString stu_no,QString root_id);

int selectShenqingOfRoot(char *rootno);

bool getRootOfClass(QString rootno , QString &SWC_NUNBER);

int getUserWithClassToListStudent(QString rootno);

bool deleteUserWithClass(QString stu_no);

bool findStuIsOnClass(QString stu_no);

bool updateHolder(Holder holderNo);

bool updateRoot(Root root);
#endif // SQLHANSHU_H




















