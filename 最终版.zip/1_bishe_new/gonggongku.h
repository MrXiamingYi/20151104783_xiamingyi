#ifndef GONGGONGKU_H
#define GONGGONGKU_H
#include <QString>
#include <stdlib.h>
#include <stdio.h>

char * QStoCH(QString filename);

#endif // GONGGONGKU_H
