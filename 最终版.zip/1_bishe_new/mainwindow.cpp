#include <QMessageBox>
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->comboBox->addItem("学生端");
    ui->comboBox->addItem("管理员");

    ui->lineEdit->setPlaceholderText("请输入六位");
    ui->lineEdit_2->setPlaceholderText("请输入六位");
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);
}

MainWindow::~MainWindow()
{
    delete ui;
}

/*---------------------------------------------*/


//获取用户名密码
void MainWindow::on_pushButton_5_clicked()
{

    QString rootOrStudent = ui->comboBox->currentText();

    if(rootOrStudent == "学生端"){
        Holder holder;
        //1.获取用户名和密码
        char holderpasswd[7] = "";
        char holderno[7] = "";
        if(ui->lineEdit_2->text().length() == 6 && ui->lineEdit->text().length() == 6){
            strcpy(holderpasswd,QStoCH(ui->lineEdit_2->text()));
            strcpy(holderno,QStoCH(ui->lineEdit->text()));
        }
        else{
            QMessageBox::information(this, "提示", "登入失败！帐号密码长度不对", QMessageBox::Ok);
        }
        if(strlen(holderno) == 6 && strlen(holderpasswd) == 6){
            //判断holdernumber是否存在
            bool ok_getholder = getHolderNo(holderno,holder);
            qDebug()<< "~~~~~1~~3~~~4~~~"<<ok_getholder<<endl;
            qDebug()<<holder.PASSWORD <<"------"<<holder.HOLD_NO<<endl;
            if(ok_getholder){

                if(ok_getholder == 0){
                    //qDebug()<< "~~~~~~~~~~~~~~"<<ok_getholder<<endl;
                    QMessageBox::information(this, "提示", "登入失败！未注册，请先注册", QMessageBox::Ok);
                }
                //qDebug()<< "strcmp"<<holderpasswd<< QStoCH(holder.PASSWORD)<<endl;

                else{
                   qDebug()<< "strcmp"<<holderpasswd<<holder.PASSWORD<<endl;
                   qDebug()<< "帐号正确"<<endl;
                }
                if (strcmp(holderpasswd,QStoCH(holder.PASSWORD)) == 0){
                    //登录成功显示主窗口
                    Student_window *first_stu = new Student_window();
                    first_stu->setWindowTitle("用户主界面");
                    //建立连接
                    QObject::connect(this, SIGNAL(sendHolderno(QString)), first_stu, SLOT(recHolderno(QString)));
                    //发射信号
                    emit sendHolderno(ui->lineEdit->text());
                    first_stu->setAttribute(Qt::WA_DeleteOnClose);
                    this->close();
                    first_stu->show();
                }
                else{
                    QMessageBox::information(this, "提示", "登入失败！用户名或密码错误", QMessageBox::Ok);
                }

            }
            else{
                QMessageBox::information(this, "提示", "登入失败！无此用户，请从新注册", QMessageBox::Ok);
            }
        }
        else{}
    }
    else {
        Root root;
        //1.获取用户名和密码
        char rootpasswd[7] = "";
        char rootno[7] = "";
        if(ui->lineEdit_2->text().length() == 6 && ui->lineEdit->text().length() == 6){
            strcpy(rootpasswd,QStoCH(ui->lineEdit_2->text()));
            strcpy(rootno,QStoCH(ui->lineEdit->text()));
        }
        else{
            QMessageBox::information(this, "提示", "登入失败！帐号密码长度不对", QMessageBox::Ok);
        }
        if(strlen(rootno) == 6 && strlen(rootpasswd) == 6){
            //判断holdernumber是否存在
            bool ok_getRoot = getRootNo(rootno,root);
            if(ok_getRoot){

                if(ok_getRoot == 0){
                    QMessageBox::information(this, "提示", "登入失败！未注册，请先注册", QMessageBox::Ok);
                }
                else{

                   qDebug()<< "帐号正确"<<endl;
                }
                if (strcmp(rootpasswd,QStoCH(root.ROOT_PASWD)) == 0){
                    //登录成功显示主窗口
                    rootWindow *secend_root = new rootWindow();
                    secend_root->setWindowTitle("管理员界面");
                    //建立连接
                    QObject::connect(this, SIGNAL(sendRootno(QString)), secend_root, SLOT(recRootno(QString)));
                    //发射信号
                    emit sendRootno(ui->lineEdit->text());
                    secend_root->setAttribute(Qt::WA_DeleteOnClose);
                    this->close();
                    secend_root->show();
                }
                else{
                    QMessageBox::information(this, "提示", "登入失败！用户名或密码错误", QMessageBox::Ok);
                }

            }
            else{
                QMessageBox::information(this, "提示", "登入失败！无此用户，请从新注册", QMessageBox::Ok);
            }
        }
        else{}
    }

}

//跳转到注册界面
void MainWindow::on_pushButton_2_clicked()
{
    QString rootOrStudent = ui->comboBox->currentText();
    if(rootOrStudent == "学生端"){
        zhuce zhuce;
        zhuce.setWindowTitle("注册界面");
        zhuce.exec();
    }
    else{
        QMessageBox::information(this, "提示", "root 用户需要分配", QMessageBox::Ok);
    }
}


void MainWindow::on_pushButton_6_clicked()
{

}
