#ifndef STUDENT_H
#define STUDENT_H

#include <QString>
class Student
{
public:
    Student(QString HOLD_NO="", QString STU_NO="", QString NAME="", QString SEC="", QString PHONE="",QString HOME="");

    QString getHold_no() const;
    void setHold_no(const QString &hold_no);

    QString get_Stu_no() const;
    void setStu_no(const QString &stu_no);

    QString getName() const;
    void setName(const QString &name);

    QString getSec() const;
    void setSec(const QString &sec);

    QString getPhone() const;
    void setPhone(const QString &phone);

    QString getHome() const;
    void setHome(const QString &home);
public:
    QString HOLD_NO;
    QString STU_NO;
    QString NAME;
    QString SEC;
    QString PHONE;
    QString HOME;
};

#endif // STUDENT_H
