#include "student_window.h"
#include "ui_student_window.h"

Student_window::Student_window(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Student_window)
{
    ui->setupUi(this);
}

Student_window::~Student_window()
{
    delete ui;
}
