#include <QtGui/QApplication>
#include "mainwindow.h"
#include <QDebug>        //输出debug
#include <QStringList>   //string
#include <QSqlDatabase>  //链接数据库

#include <QtSql>
#include <QMessageBox>
#include <QTextStream>

#include "connection.h"

int main(int argc, char *argv[])
{
        //looking jiekou
    QApplication a(argc, argv);
    qDebug()<<"begin to link sql:";
    QStringList drivers = QSqlDatabase::drivers();
    foreach(QString driver,drivers)
        qDebug() <<driver;

    bool ok = connect("xiaoyoulu");
    if( ok = false){
        qDebug()<<"connect mysql error";
    }
//    获取数据库内容
    QSqlQuery query;
    query.exec("select * from ACCOUNT");
    while(query.next())
    {
       QString id = query.value(0).toString();
       QString passwd = query.value(1).toString();
       qDebug() << id << ", " << passwd <<endl;
    }

//    获取完毕
    MainWindow w;
    w.show();
    
    return a.exec();
}
