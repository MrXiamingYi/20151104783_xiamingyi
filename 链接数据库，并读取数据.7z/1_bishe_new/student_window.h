#ifndef STUDENT_WINDOW_H
#define STUDENT_WINDOW_H

#include <QDialog>

namespace Ui {
class Student_window;
}

class Student_window : public QDialog
{
    Q_OBJECT
    
public:
    explicit Student_window(QWidget *parent = 0);
    ~Student_window();
    
private:
    Ui::Student_window *ui;
};

#endif // STUDENT_WINDOW_H
