#ifndef CONNECTION_H
#define CONNECTION_H

#endif // CONNECTION_H

#include "mainwindow.h"
#include <QApplication>
#include <QLabel>
#include <QPushButton>
#include <QtCore/QCoreApplication>
#include <QCoreApplication>
#include <QSpinBox>
#include <QSlider>
#include <QHBoxLayout>
#include <QFile>
#include <QFileInfo>
#include <QDebug>
#include <QtSql>
#include <QSqlQuery>
#include <QMessageBox>
#include <QSqlError>
#include <QTextCodec>

bool connect(const QString &dbName)
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setDatabaseName(dbName);
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("123456");

    if (!db.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"), db.lastError().text());
        return false;
    }
    else
    {
        QMessageBox::information(0,QObject::tr("Tips"),QObject::tr("连接数据库成功。。！"));
        return true;
    }
}
