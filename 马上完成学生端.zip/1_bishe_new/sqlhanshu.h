#ifndef SQLHANSHU_H
#define SQLHANSHU_H

#include "mainwindow.h"
#include <QApplication>
#include <QtSql>

#include <QDebug>        //输出debug
#include <QMessageBox>
#include <stdlib.h>
#include <Holder.h>
#include "Student.h"
#include "SC_W_CL.h"
#include "student_window.h"
#include "ui_student_window.h"
bool connect_xiasql(const QString &dbName);

bool getHolderNo(char *holderno , Holder &holder);

bool insertHolder(Holder holder);

bool insertStudent(char *zhuce_holderno,char *numb,char *name,char *sec,char *phone,char *jia);

bool getStudent(char *HOLD_NO,Student &student);

bool getStudentOfStuNo(QString STU_NO,Student &student);

bool updatStudent(QString name, QString sex,QString phone,QString home,QString holdno);

int selectStudentAndClass(QString holdno);

int getSC_W_CL();

#endif // SQLHANSHU_H




















