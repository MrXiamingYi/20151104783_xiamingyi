#include "mingpian.h"
#include "ui_mingpian.h"
#include <QDebug>
static int rcvcount;
static int recvnum;
mingpian::mingpian(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::mingpian)
{
    ui->setupUi(this);
}

mingpian::~mingpian()
{
    delete ui;
}
void mingpian::recCount(int count,int num)
{
    rcvcount = count;
    recvnum = num;
    qDebug()<<"rcvcount"<<count;
    qDebug()<<"rcvcount"<<num;
    Student student[rcvcount];
    QFile file("./stucount");

    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream stream(&file);
        for(int i = 0;i < rcvcount;i++){
            stream>>student[i].HOLD_NO>>student[i].STU_NO>>student[i].NAME>>student[i].SEC>>student[i].PHONE>>student[i].HOME;
        }
    }
    file.close();
    qDebug()<<"mingpian : "<<student[recvnum].STU_NO<<student[recvnum].NAME<<student[recvnum].SEC<<student[recvnum].PHONE<<student[recvnum].HOME;
    ui->label_2->setText(student[recvnum].STU_NO);
    ui->label_4->setText(student[recvnum].NAME);
    if(student[recvnum].SEC == "1"){
        ui->label_6->setText("男");
    }
    else{
        ui->label_6->setText("女");
    }
    ui->label_8->setText(student[recvnum].PHONE);
    ui->label_12->setText(student[recvnum].HOME);
}
