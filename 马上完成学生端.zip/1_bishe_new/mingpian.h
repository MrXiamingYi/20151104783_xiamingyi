#ifndef MINGPIAN_H
#define MINGPIAN_H

#include <QMainWindow>
#include <istream>
#include <iostream>
#include <ostream>
#include <sstream>
#include <fstream>
#include <QFile>
#include <QString>
#include <QTextStream>
#include "Student.h"

namespace Ui {
class mingpian;
}

class mingpian : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit mingpian(QWidget *parent = 0);
    ~mingpian();
private slots:
    void recCount(int count,int num);

private:
    Ui::mingpian *ui;
};

#endif // MINGPIAN_H
