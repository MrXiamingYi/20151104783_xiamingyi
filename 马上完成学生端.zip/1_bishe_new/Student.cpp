#include "Student.h"

Student::Student(QString hold_no,
               QString stu_no,
               QString name,
               QString sec,
               QString phone,
               QString home):
               HOLD_NO(hold_no),
               STU_NO(stu_no),
               NAME(name),
               SEC(sec),
               PHONE(phone),
               HOME(home)
{

}
QString Student::getHold_no() const
{
    return HOLD_NO;
}
void Student::setHold_no(const QString &hold_no)
{
    HOLD_NO = hold_no;
}

QString Student::get_Stu_no() const
{
    return STU_NO;
}

void Student::setStu_no(const QString &stu_no)
{
    STU_NO = stu_no;
}

QString Student::getName() const
{
    return NAME;
}
void Student::setName(const QString &name)
{
    NAME = name;
}
QString Student::getSec() const
{
    return SEC;
}
void Student::setSec(const QString &sec)
{
    SEC = sec;
}
QString Student::getPhone() const
{
    return PHONE;
}
void Student::setPhone(const QString &phone)
{
    PHONE = phone;
}
QString Student::getHome() const
{
    return HOME;
}
void Student::setHome(const QString &home)
{
    HOME = home;
}
