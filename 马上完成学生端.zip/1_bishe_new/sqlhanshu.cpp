#include "sqlhanshu.h"

bool connect_xiasql(const QString &dbName){
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("192.168.1.43");
    db.setDatabaseName(dbName);
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("123456");
    if (!db.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"), db.lastError().text());
        return false;
    }
    else
    {
        QMessageBox::information(0,QObject::tr("Tips"),QObject::tr("连接数据库成功。。！"));
        return true;
    }
}

bool getStudent(char *HOLD_NO,Student &student){
    qDebug()<<"goto getStudent "<<endl<<HOLD_NO;

    QSqlQuery query;
    char dbyuju[500] = "";
    sprintf(dbyuju,"select * from STUDENT WHERE STUDENT.HOLD_NO = \"%s\"",HOLD_NO);
    query.exec(dbyuju);
    qDebug()<<"select student OK  ";
    while(query.next()){
       student.HOLD_NO = QStoCH(query.value(0).toString());
       student.STU_NO  = query.value(1).toString();
       student.NAME    = query.value(2).toString();
       student.SEC     = query.value(3).toString();
       student.PHONE   = query.value(4).toString();
       student.HOME    = query.value(5).toString();

       if(student.HOLD_NO.isEmpty()||
               student.STU_NO.isEmpty()||
               student.NAME  .isEmpty()||
               student.SEC   .isEmpty()){
           qDebug() <<"Dont find Student " ;
           return 0;
       }
       else{
           return 1;
       }
    }
    return 0;
}

bool getHolderNo(char *holderno , Holder &holder){


    qDebug() << "*****************************************" ;
    qDebug() << "***************getHolderNo***************" ;
    qDebug() << "*****************************************" ;
    QSqlQuery query;

    char dbyuju[100] = "";
    sprintf(dbyuju,"select * from ACCOUNT where ACCOUNT.HOLD_NO = \"%s\"",holderno);
    query.exec(dbyuju);
    while(query.next()){
       holder.HOLD_NO = query.value(0).toString();
       holder.PASSWORD = query.value(1).toString();

       qDebug()<<holder.HOLD_NO ;
       qDebug()<<holder.PASSWORD ;
       if(holder.PASSWORD.isEmpty()){
           qDebug() <<"no holder!!! " ;
           return 0;
       }
       else{
           //qDebug() <<holder.HOLD_NO <<" "<<holder.PASSWORD;
           return 1;
       }
    }
    return 0;
}

bool insertHolder(Holder holder){
    QSqlQuery query;
    Holder l_holder;
    char l_holderno[7] = "";

    char dbyuju[500] = "";
    sprintf(dbyuju,"INSERT INTO ACCOUNT (HOLD_NO,PASSWORD) VALUES(\"%s\",\"%s\")",QStoCH(holder.HOLD_NO),QStoCH(holder.PASSWORD));

    qDebug()<<"holderno and paswd"<<QStoCH(holder.HOLD_NO)<<QStoCH(holder.PASSWORD) ;
    qDebug()<<dbyuju ;
    query.exec(dbyuju);
    strcpy(l_holderno,QStoCH(holder.HOLD_NO));

    if(getHolderNo(l_holderno,l_holder)){
        qDebug()<<"插入成功" ;
        return 1;
    }
    else
        return 0;
}

bool insertStudent(char *holderno,char *numb,char *name,char *sec,char *phone,char *jia){
    QSqlQuery query;
    Student l_student;

    char dbyuju[500] = "";
    sprintf(dbyuju,"INSERT INTO STUDENT (HOLD_NO,STU_NO,NAME,SEC,PHONE,HOME) VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\");",holderno,numb,name,sec,phone,jia);
    query.exec(dbyuju);
    bool ok_no = getStudent(holderno,l_student);
    if(ok_no){
        qDebug()<<"插入成功" ;
        return 1;
    }
    else
        return 0;
}

bool updatStudent(QString name, QString sex,QString phone,QString home,QString holdno){
    QSqlQuery query;
    Student student;
    QString dbyuju = QString("UPDATE STUDENT SET STUDENT.NAME = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(name).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.SEC = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(sex).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.PHONE = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(phone).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.HOME = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(home).arg(holdno);
    query.exec(dbyuju);

    getStudent(QStoCH(holdno),student);
    if(strcmp(QStoCH(student.NAME),QStoCH(name)) == 0 && strcmp(QStoCH(student.SEC),QStoCH(sex)) == 0 &&
            strcmp(QStoCH(student.HOME),QStoCH(home)) == 0 && strcmp(QStoCH(student.PHONE),QStoCH(phone)) == 0 ){
        return 1;
    }
    else
        return 0;
}


int selectStudentAndClass(QString holdno){

    qDebug()<<"\n\n-----into selectStudentAndClass  OK  -----";
    Student find;
    Student l_student[50];
    int recount;
    getStudent(QStoCH(holdno),find);
    QSqlQuery query;
    QString l_stu_no;
    int count = 0 ;
    QString dbyuju1 = QString("SELECT US_W_CL.STU_NO FROM US_W_CL WHERE US_W_CL.SWC_NUNBER = (SELECT US_W_CL.SWC_NUNBER FROM US_W_CL WHERE US_W_CL.STU_NO = \"%1\")")
            .arg(find.STU_NO);
    qDebug()<<"select US_W_CL.SWC_NUNBER sql:"<<dbyuju1;
    query.exec(dbyuju1);
    qDebug()<<"select US_W_CL.SWC_NUNBER OK:";

    for(int i = 0;i < 50;i++){
        if(!query.next()){
            break;
        }
        l_stu_no = query.value(0).toString();
        if(l_stu_no.isEmpty()){
            qDebug() <<"select US_W_CL.l_stu_no ERROR " ;
            return 0;
        }
        else{
            qDebug() <<"select US_W_CL.l_stu_no is :"<<l_stu_no ;
            if(getStudentOfStuNo(l_stu_no,l_student[count])){
                qDebug()<<"selectStudentAndClass.getStudentOfStuNo find it,\nl_student.HOLD_NO is :"<<l_student[count].HOLD_NO;
            }
            else{
                qDebug()<<"selectStudentAndClass.getStudentOfStuNo don't find it";
            }
            count ++;
        }
    }
    recount = count;
    qDebug()<<"selectStudentAndClass.count is :"<<count<<" and "<<recount;

    for(int i = 0 ; i < recount ; i++){
        qDebug()<<"selectStudentAndClass.getStudentOfStuNo find it,l_student.HOLD_NO is :"<<l_student[i].HOLD_NO;
    }
    QString count_stu[count];
    for(int i = 0 ; i < count;i++){
        if(l_student[i].PHONE.isEmpty()){
            l_student[i].PHONE = "空";
        }
        if(l_student[i].HOME.isEmpty()){
            l_student[i].HOME = "空";

        }
        count_stu[i] = QString("%1 %2 %3 %4 %5 %6").arg(l_student[i].HOLD_NO).arg(l_student[i].STU_NO).arg(l_student[i].NAME).arg(l_student[i].SEC).arg(l_student[i].PHONE).arg(l_student[i].HOME);
    }
    /**
      将这逐条录入.txt文件中
    */

    QFile file("./stucount");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
    QTextStream stream(&file);
        for(int j = 0;j < count;j++){
            stream << count_stu[j] << endl;
            qDebug()<<"count_stu["<<j<<"] is "<<count_stu[j];
        }
    }
    file.close();
    qDebug()<<"-----into selectStudentAndClass  end  -----\n";
    return recount;
}


bool getStudentOfStuNo(QString STU_NO,Student &student){
    qDebug()<<"\n-----into getStudentOfStuNo ok-----";
    qDebug()<<"getStudentOfStuNo.STU_NO is "<<STU_NO;
    QSqlQuery query;
    QString dbyuju = QString("SELECT * FROM STUDENT WHERE STUDENT.STU_NO = \"%1\";").arg(STU_NO);
    qDebug()<<"getStudentOfStuNo sql is"<<dbyuju;
    query.exec(dbyuju);
    qDebug()<<"getStudentOfStuNo.query.exec(dbyuju) OK  ";
    //qDebug()<<"getStudentOfStuNo.query.next() is "<<query.next();
    while(query.next()){
       student.HOLD_NO = query.value(0).toString();
       student.STU_NO  = query.value(1).toString();
       student.NAME    = query.value(2).toString();
       student.SEC     = query.value(3).toString();
       student.PHONE   = query.value(4).toString();
       student.HOME    = query.value(5).toString();
       qDebug()<<"getStudentOfStuNo.student.HOLD_NO is"<<student.HOLD_NO;
       qDebug()<<"getStudentOfStuNo.student.STU_NO  is"<<student.STU_NO;
       qDebug()<<"getStudentOfStuNo.student.NAME    is"<<student.NAME;
       qDebug()<<"getStudentOfStuNo.student.SEC     is"<<student.SEC;
       if(student.HOLD_NO.isEmpty()||
               student.STU_NO.isEmpty()||
               student.NAME  .isEmpty()||
               student.SEC   .isEmpty()){
           qDebug() <<"Dont find Student " ;
           qDebug()<<"-----into getStudentOfStuNo end -----\n";
           return 0;
       }
       else{
           qDebug()<<"-----into getStudentOfStuNo end -----\n";
           return 1;
       }
    }
    qDebug()<<"-----into getStudentOfStuNo end -----\n";
    return 0;
}

int getSC_W_CL(){
    qDebug()<<"\n\n-----into getSC_W_CL  OK  -----";
    SC_W_CL find[50];
    QSqlQuery query;
    int count = 0 ;
    QString dbyuju1 = QString("SELECT SC_W_CL.SWC_NUNBER,SCHOOL.SHCOOL_NAME,THE_CLASS.CLASS_NAME FROM SC_W_CL,SCHOOL,THE_CLASS WHERE SC_W_CL.SCHOOL_ID = SCHOOL.SCHOOL_ID AND SC_W_CL.CLASS_ID = THE_CLASS.CLASS_ID;");
    query.exec(dbyuju1);
    qDebug()<<"getSC_W_CL.query.exec(dbyuju1);OK:";

    for(int i = 0;i < 50;i++){
        if(!query.next()){
            break;
        }
        find[i].num = query.value(0).toString();
        find[i].school_name = query.value(1).toString();
        find[i].class_name = query.value(2).toString();
        qDebug()<<"查询出来的结果为："<<find[i].num<<find[i].school_name<<find[i].class_name;
        if(find[i].num.isEmpty()){
            qDebug() <<"select US_W_CL.l_stu_no ERROR " ;
            return 0;
        }
        count++;
    }
    for(int i = 0 ; i < count ; i++){
        qDebug()<<"selectStudentAndClass.getStudentOfStuNo find it,l_student.HOLD_NO is :"<<find[i].num;
    }
    QString addstr[count];
    for(int i = 0 ; i < count;i++){
        addstr[i] = QString("%1 %2 %3").arg(find[i].num).arg(find[i].school_name).arg(find[i].class_name);
        qDebug()<<"链接起来的字符串为："<<addstr[i];
    }

    QFile file("./SCWCL");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text)) //QIODevice::ReadWrite支持读写
    {
    QTextStream stream(&file);
        for(int j = 0;j < count;j++){
            stream << addstr[j] << endl;
            qDebug()<<"写入文件里面的字符串内容为："<<addstr[j];
        }
    }
    file.close();
    qDebug()<<"-----into selectStudentAndClass  end  -----\n";



    return count;
}













