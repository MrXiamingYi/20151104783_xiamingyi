#include <QMessageBox>
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->comboBox->addItem("学生端");
    ui->comboBox->addItem("管理员");

    ui->lineEdit->setPlaceholderText("请输入六位");
    ui->lineEdit_2->setPlaceholderText("请输入六位");
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);
}

MainWindow::~MainWindow()
{
    delete ui;
}

/*---------------------------------------------*/


//获取用户名密码
void MainWindow::on_pushButton_5_clicked()
{

    Holder holder;
    //1.获取用户名和密码
    char holderpasswd[7] = "";
    char holderno[7] = "";
    if(ui->lineEdit_2->text().length() == 6 && ui->lineEdit->text().length() == 6){
        strcpy(holderpasswd,QStoCH(ui->lineEdit_2->text()));
        strcpy(holderno,QStoCH(ui->lineEdit->text()));
    }
    else{
        QMessageBox::information(this, "提示", "登入失败！帐号密码长度不对", QMessageBox::Ok);
    }
    if(strlen(holderno) == 6 && strlen(holderpasswd) == 6){
        //判断holdernumber是否存在
        bool ok_getholder = getHolderNo(holderno,holder);
        qDebug()<< "~~~~~1~~3~~~4~~~"<<ok_getholder<<endl;
        qDebug()<<holder.PASSWORD <<"------"<<holder.HOLD_NO<<endl;
        if(ok_getholder){

            if(ok_getholder == 0){
                //qDebug()<< "~~~~~~~~~~~~~~"<<ok_getholder<<endl;
                QMessageBox::information(this, "提示", "登入失败！未注册，请先注册", QMessageBox::Ok);
            }
            //qDebug()<< "strcmp"<<holderpasswd<< QStoCH(holder.PASSWORD)<<endl;

            else{
               qDebug()<< "strcmp"<<holderpasswd<<holder.PASSWORD<<endl;
               qDebug()<< "帐号正确"<<endl;
            }
            if (strcmp(holderpasswd,QStoCH(holder.PASSWORD)) == 0){

                //登录成功显示主窗口
                Student_window *first_stu = new Student_window();

                //建立连接

                QObject::connect(this, SIGNAL(sendHolderno(QString)), first_stu, SLOT(recHolderno(QString)));
                //发射信号
                emit sendHolderno(ui->lineEdit->text());
                first_stu->setAttribute(Qt::WA_DeleteOnClose);
                this->close();
                first_stu->show();
            }
            else{
                QMessageBox::information(this, "提示", "登入失败！用户名或密码错误", QMessageBox::Ok);
            }

        }
        else{
            QMessageBox::information(this, "提示", "登入失败！无此用户，请从新注册", QMessageBox::Ok);
        }
    }
    else{

    }


}

//跳转到注册界面
void MainWindow::on_pushButton_2_clicked()
{
    zhuce zhuce;
    zhuce.exec();
}

