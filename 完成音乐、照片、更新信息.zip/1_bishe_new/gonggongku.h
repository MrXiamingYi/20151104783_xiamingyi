#ifndef GONGGONGKU_H
#define GONGGONGKU_H
#include <QString>
#include <stdlib.h>
#include <stdio.h>

char * QStoCH(QString filename);
QString * CHtoQS(char ch);

#endif // GONGGONGKU_H
