#ifndef SQLHANSHU_H
#define SQLHANSHU_H

#include "mainwindow.h"
#include <QApplication>
//#include <QLabel>
//#include <QPushButton>
//#include <QtCore/QCoreApplication>
//#include <QCoreApplication>
//#include <QSpinBox>
//#include <QSlider>
//#include <QHBoxLayout>
//#include <QFile>
//#include <QFileInfo>
#include <QtSql>
//#include <QSqlQuery>
//#include <QMessageBox>
//#include <QSqlError>
//#include <QTextCodec>
#include <QDebug>        //输出debug
//#include <QStringList>   //string
#include <QMessageBox>

#include <Holder.h>

bool connect_xiasql(const QString &dbName);

bool getHolderNo(char *holderno , Holder &holder);

bool insertHolder(Holder holder);

bool insertStudent(char *zhuce_holderno,char *numb,char *name,char *sec,char *phone,char *jia);

bool getStudent(char *HOLD_NO,Student &student);

bool updatStudent(QString name, QString sex,QString phone,QString home,QString holdno);
#endif // SQLHANSHU_H




















