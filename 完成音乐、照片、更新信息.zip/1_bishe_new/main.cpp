#include <QtGui/QApplication>
#include <QTextCodec>
#include "mainwindow.h"
#include "sqlhanshu.h"

int main(int argc, char *argv[])
{
    // 设置中文输出  begin
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF8"));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF8"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF8"));
    // 设置中文输出  end



    //查看QT接口 begin
    QApplication a(argc, argv);
    qDebug()<<"begin to link sql:";
    QStringList drivers = QSqlDatabase::drivers();
    foreach(QString driver,drivers)
        qDebug() <<driver;
    bool ok = connect_xiasql("xiaoyoulu");
    if( ok = false){
        qDebug()<<"connect mysql error";
    }

    //查看中文接口 end
    MainWindow w;
    w.show();
    
    return a.exec();
}
