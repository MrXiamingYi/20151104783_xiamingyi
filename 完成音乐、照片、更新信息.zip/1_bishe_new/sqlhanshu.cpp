#include "sqlhanshu.h"

bool connect_xiasql(const QString &dbName){
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("192.168.1.43");
    db.setDatabaseName(dbName);
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("123456");
    if (!db.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"), db.lastError().text());
        return false;
    }
    else
    {
        QMessageBox::information(0,QObject::tr("Tips"),QObject::tr("连接数据库成功。。！"));
        return true;
    }
}

bool getStudent(char *HOLD_NO,Student &student){
    qDebug()<<"goto getStudent "<<endl<<HOLD_NO;

    QSqlQuery query;
    char dbyuju[500] = "";
    sprintf(dbyuju,"select * from STUDENT WHERE STUDENT.HOLD_NO = \"%s\"",HOLD_NO);
    query.exec(dbyuju);
    qDebug()<<"select student OK  ";
    while(query.next()){
       student.HOLD_NO = query.value(0).toString();
       student.STU_NO  = query.value(1).toString();
       student.NAME    = query.value(2).toString();
       student.SEC     = query.value(3).toString();
       student.PHONE   = query.value(4).toString();
       student.HOME    = query.value(5).toString();

       if(student.HOLD_NO.isEmpty()||
               student.STU_NO.isEmpty()||
               student.NAME  .isEmpty()||
               student.SEC   .isEmpty()){
           qDebug() <<"Dont find Student " ;
           return 0;
       }
       else{
           return 1;
       }
    }
    return 0;
}

bool getHolderNo(char *holderno , Holder &holder){

    QSqlQuery query;

    char dbyuju[100] = "";
    sprintf(dbyuju,"select * from ACCOUNT where ACCOUNT.HOLD_NO = \"%s\"",holderno);
    query.exec(dbyuju);
    while(query.next()){
       holder.HOLD_NO = query.value(0).toString();
       holder.PASSWORD = query.value(1).toString();

       qDebug()<<holder.HOLD_NO ;
       qDebug()<<holder.PASSWORD ;
       if(holder.PASSWORD.isEmpty()){
           qDebug() <<"no holder!!! " ;
           return 0;
       }
       else{
           //qDebug() <<holder.HOLD_NO <<" "<<holder.PASSWORD;
           return 1;
       }
    }
    return 0;
}

bool insertHolder(Holder holder){
    QSqlQuery query;
    Holder l_holder;
    char l_holderno[7] = "";

    char dbyuju[500] = "";
    sprintf(dbyuju,"INSERT INTO ACCOUNT (HOLD_NO,PASSWORD) VALUES(\"%s\",\"%s\")",QStoCH(holder.HOLD_NO),QStoCH(holder.PASSWORD));

    qDebug()<<"holderno and paswd"<<QStoCH(holder.HOLD_NO)<<QStoCH(holder.PASSWORD) ;
    qDebug()<<dbyuju ;
    query.exec(dbyuju);
    strcpy(l_holderno,QStoCH(holder.HOLD_NO));

    if(getHolderNo(l_holderno,l_holder)){
        qDebug()<<"插入成功" ;
        return 1;
    }
    else
        return 0;
}

bool insertStudent(char *holderno,char *numb,char *name,char *sec,char *phone,char *jia){
    QSqlQuery query;
    Student l_student;

    char dbyuju[500] = "";
    sprintf(dbyuju,"INSERT INTO STUDENT (HOLD_NO,STU_NO,NAME,SEC,PHONE,HOME) VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\");",holderno,numb,name,sec,phone,jia);
    query.exec(dbyuju);
    bool ok_no = getStudent(holderno,l_student);
    if(ok_no){
        qDebug()<<"插入成功" ;
        return 1;
    }
    else
        return 0;
}

bool updatStudent(QString name, QString sex,QString phone,QString home,QString holdno){
    QSqlQuery query;
    Student student;
    QString dbyuju = QString("UPDATE STUDENT SET STUDENT.NAME = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(name).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.SEC = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(sex).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.PHONE = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(phone).arg(holdno);
    query.exec(dbyuju);
    dbyuju = QString("UPDATE STUDENT SET STUDENT.HOME = \"%1\" WHERE STUDENT.HOLD_NO = \"%2\";")
            .arg(home).arg(holdno);
    query.exec(dbyuju);

    getStudent(QStoCH(holdno),student);
    if(strcmp(QStoCH(student.NAME),QStoCH(name)) == 0 && strcmp(QStoCH(student.SEC),QStoCH(sex)) == 0 &&
            strcmp(QStoCH(student.HOME),QStoCH(home)) == 0 && strcmp(QStoCH(student.PHONE),QStoCH(phone)) == 0 ){
        return 1;
    }
    else
        return 0;
}






















