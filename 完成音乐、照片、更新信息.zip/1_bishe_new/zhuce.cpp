#include "zhuce.h"
#include "ui_zhuce.h"
#include <QDebug>
zhuce::zhuce(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::zhuce)
{
    ui->setupUi(this);
}

zhuce::~zhuce()
{

    delete ui;
}

void zhuce::on_pushButton_clicked()
{
    char zhuce_holderno[7] = "";
    char zhuce_passwd[7] = "";
    char zhuce_name[9] = "";
    char zhuce_sec[3] = "";
    char zhuce_numb[61] = "";
    char zhuce_phone[13] = "";
    char zhuce_jia[13] = "";

    QString l_sec;
    Holder holder;

    strcpy(zhuce_holderno , QStoCH (ui->lineEdit_6->text()));
    qDebug()<<zhuce_holderno<<endl;
    strcpy(zhuce_passwd   , QStoCH (ui->lineEdit_2->text()));
    qDebug()<<zhuce_passwd<<endl;
    strcpy(zhuce_name     , QStoCH (ui->lineEdit_5->text()));
    qDebug()<<zhuce_name<<endl;
    l_sec = ui->radioButton->isChecked() ? "1" : "0";
    strcpy(zhuce_sec      , QStoCH (l_sec));
    qDebug()<<zhuce_sec<<endl;
    strcpy(zhuce_numb     , QStoCH (ui->lineEdit_3->text()));
    qDebug()<<zhuce_numb<<endl;
    strcpy(zhuce_phone    , QStoCH (ui->lineEdit_4->text()));
    qDebug()<<zhuce_phone<<endl;
    strcpy(zhuce_jia      , QStoCH (ui->lineEdit_7->text()));
    qDebug()<<zhuce_jia<<endl;

    if(strlen(zhuce_holderno) == 6 && strlen(zhuce_passwd) ==6 ){
        if(strlen(zhuce_name) != 0){
            if(strlen(zhuce_sec) != 0){
                bool yes_no = getHolderNo(zhuce_holderno,holder);
                if(yes_no == 1){
                    QMessageBox::information(this, "提示", "帐号已经存在", QMessageBox::Ok);
                }
                holder.HOLD_NO  = zhuce_holderno;
                holder.PASSWORD = zhuce_passwd;
                yes_no = insertHolder(holder);
                if(yes_no == 0){
                    qDebug()<<"Holder插入失败"<<endl;
                }
                yes_no = insertStudent(zhuce_holderno,zhuce_numb,zhuce_name,zhuce_sec,zhuce_phone,zhuce_jia);
                if(yes_no == 0){
                    qDebug()<<"Student插入失败"<<endl;
                }
                else{
                    QMessageBox::information(this, "提示", "注册完毕,请登录。", QMessageBox::Ok);
                     this->close();
                }
            }
            else{
                QMessageBox::information(this, "提示", "没有选择性别", QMessageBox::Ok);
            }
        }
        else{
            QMessageBox::information(this, "提示", "姓名不能为空", QMessageBox::Ok);
        }
    }
    else{
        QMessageBox::information(this, "提示", "帐号密码长度不对", QMessageBox::Ok);
    }

}
