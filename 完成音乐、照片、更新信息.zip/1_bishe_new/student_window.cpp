#include "student_window.h"
#include "ui_student_window.h"

Student_window::Student_window(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Student_window)
{
    ui->setupUi(this);

    qDebug()<<"---------------------------------";
    qDebug()<<"---------进入学生用户主界面---------";
    qDebug()<<"---------------------------------";

    /**初始化媒体**/
    audio =new Phonon::MediaObject();//媒体对象
    audio->setTickInterval(1);
    audioOutput = new Phonon::AudioOutput(Phonon::VideoCategory);//音频输出
    Phonon::createPath( audio, audioOutput);//连接媒体对象与音频输出

    musicInformationMediaObject = new Phonon::MediaObject(this);  //音乐信息对象

    volumeSlider = new Phonon::VolumeSlider( audioOutput,this);  //音量滑动条
    volumeSlider->move(285,60);
    volumeSlider->resize(50,20);
    volumeSlider->setStyleSheet("background-color:rgb(255,255,255,100)");
    volumeSlider->setFixedWidth(100);//固定音量条大小

    seekSlider = new Phonon::SeekSlider( audio,this); //进度滑动条 将进度条与媒体对象连接
    seekSlider->move(240,20);
    seekSlider->resize(170,20);
    seekSlider->setStyleSheet("background-color:rgb(255,255,255,100)");

}

Student_window::~Student_window()
{
    delete ui;
}

void Student_window::recHolderno(QString holdno)
{
    QString str = QString("已经传入账户号： %1").arg(holdno);
    qDebug()<<str;
    s_holdno = holdno;
}
//播放/暂停
void Student_window::on_toolButton_playpause_clicked(){
    if(sourceList.isEmpty())
        {
            return ;
        }
        audio->setQueue(sourceList);//列表循环

    if(audio->state() == Phonon::PlayingState)
        audio->pause();
    else
    {
        audio->play();
    }

}

//停止播放
void Student_window::on_toolButton_stop_clicked(){
    audio->stop();
}

//打开文件
void Student_window::on_toolButton_open_clicked(){

    QStringList files = QFileDialog::getOpenFileNames(this, tr("Selec Files to play"),QDesktopServices::storageLocation(QDesktopServices::MusicLocation));

    qDebug()<<"第"<<files<<"条";
    // 使用 QFileDialog 的 getOpenFileNames 方法获取若干个音乐文件，
    QString file;

    foreach(file, files)// 使用 Qt 中的 foreach 遍历每个选中的文件，将其添加到播放列表中。
    {
        QString muzicname;
        muzicname = file.section('/', -1);
        ui->listWidget->addItem(muzicname);
        sourceList.append(file);
    }
}

//上一首歌
void Student_window::on_toolButton_previous_clicked()
{
    if(sourceList.count() != 0){
        /*查找当前媒体播放的位置，返回给index*/
        int index = sourceList.indexOf(audio->currentSource());
        qDebug()<<"共"<<sourceList.count()<<"条";
        qDebug()<<"第"<<index<<"条";
        if(index - 1 >= 0){
            audio->setCurrentSource(sourceList.at(index - 1));
            audio->play();
        }
        else {
            QMessageBox::information(this, "提示", "已经第一首了！", QMessageBox::Ok);
        }
    }
    else{
        QMessageBox::information(this, "提示", "播放列表为空", QMessageBox::Ok);
    }
}

//下一首
void Student_window::on_toolButton_next_clicked()
{
    if(sourceList.count() != 0){
        int index = sourceList.indexOf(audio->currentSource());
        qDebug()<<"共"<<sourceList.count()<<"条";
        qDebug()<<"第"<<index<<"条";
        if(index +1 <= sourceList.count()-1){
            audio->setCurrentSource(sourceList.at(index + 1));
            audio->play();
        }
        else {
            QMessageBox::information(this, "提示", "已经最后一首了！", QMessageBox::Ok);
        }
    }
    else{
        QMessageBox::information(this, "提示", "播放列表为空", QMessageBox::Ok);
    }
}

//删除文件
void Student_window::on_toolButton_lrcD_clicked()
{
    QStringList files = QFileDialog::getOpenFileNames(this, tr("delete muzic"),QDesktopServices::storageLocation(QDesktopServices::MusicLocation));
    QString file;
    foreach(file, files)// 使用 Qt 中的 foreach 遍历每个选中的文件，将其添加到播放列表中。
    {
        //删除文件
        QFile::remove(file); //提示
    }

    QMessageBox::warning(this,"删除文件","删除成功！");

}




void Student_window::on_pushButton_6_clicked()
{
    qDebug()<<"全局变量 s_holdno ："<<s_holdno;
    QString name  = ui->lineEdit_1->text();
    QString phone = ui->lineEdit_6->text();
    QString home  = ui->lineEdit_8->text();
    QString sex   = ui->radioButton->isChecked() ? "1" : "0";

    qDebug()<<"要更改的 name: "<<name ;
    qDebug()<<"要更改的 phone:"<<phone;
    qDebug()<<"要更改的 home: "<<home ;
    qDebug()<<"要更改的 sex:  "<<sex  ;

    if(!name.isEmpty() && !phone.isEmpty() && !home.isEmpty() && !sex.isEmpty()){
        bool ok_no = updatStudent( name,  sex, phone, home, s_holdno);
        if(ok_no){
            QMessageBox::information(this, "提示", "录入成功", QMessageBox::Ok);
        }
        else
            QMessageBox::information(this, "提示", "录入失败", QMessageBox::Ok);
    }
    else
         QMessageBox::information(this, "提示", "您少输入了", QMessageBox::Ok);
}
/*********************************minage begin************************************/

void Student_window::on_pushButton_3_clicked()
{
    qDebug() << "*****************************************" ;
    qDebug() << "***************打开照片按钮按**************" ;
    qDebug() << "*****************************************" ;

    /****************打开文件 begin****************/
    filename = QFileDialog::getOpenFileName(this, tr("Select image:"),
            QDesktopServices::storageLocation(QDesktopServices::PicturesLocation));
    if (filename.isEmpty()) {
        return ;
    }
    s_photoname = filename;
    qDebug() << "s_photoname : "<<s_photoname ;
    QImage image;
    if (!image.load(filename)) {
        QMessageBox::information(this, tr("Error"), tr("打开照片失败"));
        return ;
    }
    /****************打开文件 end******************/

    /****************图片居中，增加滚轮 begin****************/
    ui->label_2->setAlignment(Qt::AlignHCenter);
    ui->label_2->setAlignment(Qt::AlignCenter);
    ui->label_2->setPixmap(QPixmap::fromImage(image)); //图片显示
    ui->scrollArea->setWidget(ui->label_2);            //传递给scorllarea显示
    /****************图片居中，增加滚轮 end******************/

    s_chimage = QImage(image);

}

void Student_window::on_pushButton_8_clicked()
{
    qDebug() << "*****************************************" ;
    qDebug() << "***************点击关闭钮按****************" ;
    qDebug() << "*****************************************" ;
    ui->label_2->clear();

    s_chimage = QImage();
}

void Student_window::on_pushButton_9_clicked()
{
    qDebug() << "*****************************************" ;
    qDebug() << "***************左翻页*********************" ;
    qDebug() << "*****************************************" ;

    int now_photo = 0;
    imgInfoList.clear();
    QDir dir = QFileInfo(s_photoname).absolutePath();
    qDebug() << "on_pushButton_3_clicked.s_photoname:" << s_photoname;
    QFileInfoList infoList = dir.entryInfoList(QDir::Files);//存的 “/home/图片” 文件的信息
    qDebug() << "on_pushButton_3_clicked.GET:" << infoList.count() << "\n dir:"<<dir;
    QFileInfo info; //文件信息获取

    for (int i = 0; i < infoList.count(); i++) {
        info = infoList.at(i);
        qDebug() << i << info.fileName();
        now_photo = i;
        if(s_photoname.section('/', -1) == info.fileName()){
            qDebug() << "now file number is " << now_photo;
            break;
        }
    }

    if( now_photo-1 >= 0){
        QFileInfo nextfile;
        nextfile = infoList.at(now_photo-1);
        qDebug()<<nextfile.filePath();

        QImage image;
        if (!image.load(nextfile.filePath())) {
            QMessageBox::information(this, tr("Error"), tr("打开照片失败"));
            return ;
        }
        ui->label_2->setAlignment(Qt::AlignHCenter);
        ui->label_2->setAlignment(Qt::AlignCenter);
        ui->label_2->setPixmap(QPixmap::fromImage(image)); //图片显示
        ui->scrollArea->setWidget(ui->label_2);            //传递给scorllarea显示

        s_photoname = nextfile.filePath();
        s_chimage = QImage(image);
    }
    else {
        QMessageBox::information(this, "提示", "已经是第一张了", QMessageBox::Ok);
    }

}
void Student_window::on_pushButton_10_clicked()
{
    qDebug() << "*****************************************" ;
    qDebug() << "***************右翻页*********************" ;
    qDebug() << "*****************************************" ;

    int now_photo = 0;
    imgInfoList.clear();
    QDir dir = QFileInfo(s_photoname).absolutePath();
    qDebug() << "on_pushButton_3_clicked.s_photoname:" << s_photoname;
    QFileInfoList infoList = dir.entryInfoList(QDir::Files);//存的 “/home/图片” 文件的信息
    qDebug() << "on_pushButton_3_clicked.GET:" << infoList.count() << "\n dir:"<<dir;
    QFileInfo info; //文件信息获取

    for (int i = 0; i < infoList.count(); i++) {
        info = infoList.at(i);
        qDebug() << i << info.fileName();
        now_photo = i;
        if(s_photoname.section('/', -1) == info.fileName()){
            qDebug() << "now file number is " << now_photo;
            break;
        }
    }

    if(now_photo+1 <= infoList.count()-1){
        QFileInfo nextfile;
        nextfile = infoList.at(now_photo+1);
        qDebug()<<nextfile.filePath();

        QImage image;
        if (!image.load(nextfile.filePath())) {
            QMessageBox::information(this, tr("Error"), tr("打开照片失败"));
            return ;
        }
        ui->label_2->setAlignment(Qt::AlignHCenter);
        ui->label_2->setAlignment(Qt::AlignCenter);
        ui->label_2->setPixmap(QPixmap::fromImage(image)); //图片显示
        ui->scrollArea->setWidget(ui->label_2);            //传递给scorllarea显示

        s_photoname = nextfile.filePath();
        s_chimage = QImage(image);
    }
    else {
        QMessageBox::information(this, "提示", "已经是最后了", QMessageBox::Ok);
    }

}

void Student_window::on_pushButton_13_clicked()
{
    qDebug() << "*****************************************" ;
    qDebug() << "***************放大***********************" ;
    qDebug() << "*****************************************" ;
    qreal width = s_chimage.width(); //获得以前图片的宽和高
    qreal height = s_chimage.height();
    s_chimage = QImage(s_chimage.scaled(width*1.1,height*1.1,Qt::KeepAspectRatio));
    ui->label_2->setAlignment(Qt::AlignHCenter);
    ui->label_2->setAlignment(Qt::AlignCenter);
    ui->label_2->setPixmap(QPixmap::fromImage(s_chimage)); //图片显示
    ui->scrollArea->setWidget(ui->label_2);            //传递给scorllarea显示
}


void Student_window::on_pushButton_14_clicked()
{
    qDebug() << "*****************************************" ;
    qDebug() << "***************缩小***********************" ;
    qDebug() << "*****************************************" ;
    qreal width = s_chimage.width(); //获得以前图片的宽和高
    qreal height = s_chimage.height();
    s_chimage = QImage(s_chimage.scaled(width/1.1,height/1.1,Qt::KeepAspectRatio));
    ui->label_2->setAlignment(Qt::AlignHCenter);
    ui->label_2->setAlignment(Qt::AlignCenter);
    ui->label_2->setPixmap(QPixmap::fromImage(s_chimage)); //图片显示
    ui->scrollArea->setWidget(ui->label_2);            //传递给scorllarea显示
}


void Student_window::on_pushButton_15_clicked()
{
    qDebug() << "*****************************************" ;
    qDebug() << "***************删除***********************" ;
    qDebug() << "*****************************************" ;
    QString file = QString(s_photoname);
    if(QFile::remove(file)){
        QMessageBox::warning(this,"删除文件","删除成功！");

        ui->label_2->clear();
        s_chimage = QImage();
    }
    else{
        QMessageBox::warning(this,"删除文件","删除失败！");
    }
}
/*********************************minage end***************************************/





