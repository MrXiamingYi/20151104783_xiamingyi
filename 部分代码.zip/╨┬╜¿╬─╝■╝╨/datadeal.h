#ifndef DATADEAL_H
#define DATADEAL_H

#include <QWidget>

extern QByteArray QString2Hex(QString str); //将字符型进制转化为16进制
extern QString ShowHex(QByteArray str);     //将接收的一串QByteArray类型的16进制,转化为对应的字符串16进制
extern QString Convert4Hex(QByteArray str); //将接收的一串QByteArray类型的16进制,每2个16进制转化为1个字的16进制的字符串
#endif // DATADEAL_H
