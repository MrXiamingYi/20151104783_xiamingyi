#ifndef OPERATESQL_H
#define OPERATESQL_H

#include <QSqlDatabase>
#include <QMap>
#include <QVector>

class operateSQL
{
public:
    operateSQL();
    bool connect();
    QSqlDatabase database();

    QString checkLogin(QVector<QString> stringList);

    QMap<QString,QString> sInfor(QString stringList);
    QMap<QString,QString> tInfor(QString stringList);
    QMap<QString,QString> aInfor(QString stringList);

    void alterSInfor(QMap<QString,QString> sInfor,QString id);
    void alterTInfor(QMap<QString,QString> tInfor,QString id);
    void alterAInfor(QMap<QString,QString> aInfor,QString id);


    void insertScore(QVector<QMap<QString,QString> > scoreInfor);

    QVector<QMap<QString,QString> > sScore(QString id);

    void insertIndivInfor(QMap<QString,QString> newInfor,QString authority);

private:
    QSqlDatabase db;


};

#endif // OPERATESQL_H
