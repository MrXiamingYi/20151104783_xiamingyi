#include "operatesql.h"


#include <QSqlQuery>
#include <QMessageBox>
#include <QSqlError>
#include <QVariant>
#include <QStringList>
#include <QDebug>
#include <QSqlRecord>


operateSQL::operateSQL()
{

}


bool operateSQL::connect()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("student.db");
    //db.setUserName ("");
    //db.setPassword ("");

    if(!db.open()) {
            QMessageBox::critical(0, QObject::tr("Database Error"),
                db.lastError().text());
            return false;
    }
    return true;
}


QSqlDatabase operateSQL::database ()
{
    return db;
}

QString operateSQL::checkLogin (QVector<QString> stringList)
{
    QSqlQuery query(db);
    QString text(QString("select id,authority from student where id='%1' and code='%2' union "
                 "select id,authority from Administrator where id='%3'and code='%4' union "
                 "select id,authority from teacher where id='%5' and code='%6'").arg (stringList[0],stringList[1],stringList[0],
                                                                            stringList[1],stringList[0],stringList[1]));

    query.exec (text);

    if(!query.isActive ())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"),
                              query.lastError ().text ());
    }
    if(!query.next ())
    {
        return NULL;
    }
    else
    {
        return query.value (1).toString ();
    }


}


QMap<QString,QString> operateSQL::sInfor (QString stringList)
{
    QSqlQuery query(db);

    QString text(QString("select * from student where id='%1'").arg (stringList));
    query.exec (text);

    if(!query.isActive ())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"),
                              text);
    }

    QMap <QString,QString> sInfor;

    QSqlRecord sRecord;

    while(query.next ())
    {
        sRecord=query.record ();
    }

    sInfor.insert ("id",sRecord.value ("id").toString ());
    sInfor.insert ("name",sRecord.value ("name").toString ());
    sInfor.insert ("sex",sRecord.value ("sex").toString ());
    sInfor.insert ("department",sRecord.value ("department").toString ());
    sInfor.insert ("class",sRecord.value("class").toString ());
    sInfor.insert ("major",sRecord.value ("major").toString ());
    sInfor.insert ("born_date",sRecord.value ("born_date").toString ());
    sInfor.insert ("enroll_date",sRecord.value ("enroll_date").toString ());
    sInfor.insert ("telephone",sRecord.value ("telephone").toString ());

    return sInfor;
}


QMap<QString,QString> operateSQL::tInfor (QString stringList)
{
    QSqlQuery query(db);

    QString text(QString("select * from teacher where id='%1'").arg (stringList));
    query.exec (text);

    if(!query.isActive ())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"),
                              text);
    }

    QMap <QString,QString> tInfor;

    QSqlRecord tRecord;

    while(query.next ())
    {
        tRecord=query.record ();
    }

    tInfor.insert ("id",tRecord.value ("id").toString ());
    tInfor.insert ("name",tRecord.value ("name").toString ());
    tInfor.insert ("sex",tRecord.value ("sex").toString ());
    tInfor.insert ("department",tRecord.value ("department").toString ());
    tInfor.insert ("born_date",tRecord.value ("born_date").toString ());
    tInfor.insert ("enroll_date",tRecord.value ("enroll_date").toString ());
    tInfor.insert ("telephone",tRecord.value ("telephone").toString ());

    return tInfor;
}

QMap<QString,QString> operateSQL::aInfor (QString stringList)
{
    QSqlQuery query(db);

    QString text(QString("select * from Administrator where id='%1'").arg (stringList));
    query.exec (text);

    if(!query.isActive ())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"),
                              text);
    }

    QMap <QString,QString> aInfor;

    QSqlRecord aRecord;

    while(query.next ())
    {
        aRecord=query.record ();
    }

    aInfor.insert ("id",aRecord.value ("id").toString ());
    aInfor.insert ("name",aRecord.value ("name").toString ());
    aInfor.insert ("sex",aRecord.value ("sex").toString ());

    aInfor.insert ("enroll_date",aRecord.value ("enroll_date").toString ());
    aInfor.insert ("telephone",aRecord.value ("telephone").toString ());

    return aInfor;
}


void operateSQL::alterSInfor (QMap<QString, QString> sInfor,QString id)
{
    QSqlQuery query(db);

    QList<QString> keyList;
    keyList=sInfor.keys ();

    for(int i=0;i<sInfor.size ();i++)
    {

        QString text(QString("UPDATE student SET %1 = '%2' where id='%3'").arg (keyList[i],sInfor.value (keyList[i]),id));
        query.exec (text);

        if(!query.isActive ())
        {
            QMessageBox::critical(0, QObject::tr("Database Error"),
                                  text);
        }
    }

}

void operateSQL::alterTInfor (QMap<QString, QString> tInfor,QString id)
{

    QSqlQuery query(db);

    QList<QString> keyList;
    keyList=tInfor.keys ();

    for(int i=0;i<tInfor.size ();i++)
    {

        QString text(QString("UPDATE teacher SET %1 = '%2' where id='%3'").arg (keyList[i],tInfor.value (keyList[i]),id));
        query.exec (text);

        if(!query.isActive ())
        {
            QMessageBox::critical(0, QObject::tr("Database Error"),
                                  text);
        }
    }
}

void operateSQL::alterAInfor (QMap<QString, QString> aInfor,QString id)
{

    QSqlQuery query(db);

    QList<QString> keyList;
    keyList=aInfor.keys ();

    for(int i=0;i<aInfor.size ();i++)
    {

        QString text(QString("UPDATE teacher SET %1 = '%2' where id='%3'").arg (keyList[i],aInfor.value (keyList[i]),id));
        query.exec (text);

        if(!query.isActive ())
        {
            QMessageBox::critical(0, QObject::tr("Database Error"),
                                  text);
        }
    }
}


QVector<QMap<QString,QString> > operateSQL::sScore (QString id)
{
    QSqlQuery query(db);



    QString text(QString("select c.course_id,c.course_name,mark,c.course_type,t.name from "
                         "course_infor c,score,teacher t where score.student_id='%1' and "
                         "c.course_id=score.course_id and t.id=c.course_teacher_id").arg (id));
    query.exec (text);


    QSqlRecord record ;

    QVector<QMap<QString,QString> > sScoreInfor;

    if(!query.isActive ())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"),
                              query.lastError ().text ());
    }


    else
    {
        while(query.next ())
        {
            record =query.record ();
            QMap<QString,QString> infor;

            infor.insert ("course_id",record.value ("course_id").toString ());
            infor.insert ("course_name",record.value ("course_name").toString ());
            infor.insert ("mark",record.value ("mark").toString ());
            infor.insert ("course_type",record.value ("course_type").toString ());
            infor.insert ("name",record.value ("name").toString ());

            sScoreInfor.append (infor);

        }

    }
    return sScoreInfor;

}


void operateSQL::insertScore (QVector<QMap<QString,QString> > scoreInfor)
{
    QSqlQuery query(db);



    for(int i=0;i<scoreInfor.size ();i++)
    {
        QString text(QString("update score set mark='%1' where student_id='%2' and course_id='%3'").arg (scoreInfor[i].value ("mark"),scoreInfor[i].value ("student_id"),scoreInfor[i].value ("course_id")));
        query.exec (text);

        if(!query.isActive ())
        {
            QMessageBox::critical(0, QObject::tr("Database Error"),
                                  query.lastError ().text ());
        }
    }
}


void operateSQL::insertIndivInfor (QMap<QString, QString> newInfor, QString authority)
{
    QSqlQuery query(db);

    QList<QString> keyList;

    keyList=newInfor.keys ();
    QString attributes;
    for(int attribute=0;attribute<keyList.size ();attribute++)
    {
        attributes.append (keyList[attribute]);

        if(attribute!=keyList.size ()-1)
        {
            attributes.append (",");
        }
    }

    QString values;
    for(int value=0;value<keyList.size ();value++)
    {
        values.append ("'"+newInfor.value (keyList[value])+"'");
        if(value!=keyList.size ()-1)
        {
            values.append (",");
        }
    }

    QString text(QString("insert into %1(%2) values(%3) ").arg (authority,attributes,values));

    query.exec (text);

    if(!query.isActive ())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"),
                              text );
    }

}
